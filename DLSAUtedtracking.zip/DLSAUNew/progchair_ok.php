<?php
	session_start();
	require_once 'admin/conn.php';
	
	
function alert($msg) {
    echo "<script type='text/javascript'>alert('$msg');</script>";
}
//alert($_SESSION['idnum']);
	mysqli_query($conn, "UPDATE `approval` SET submitted='--', progsub = '--', deansub = '--', regsub = '--', hrsub = '--', vcarsub = '--', reject = '--', progchair = '--' Where IDnum = '$_SESSION[idnum]'") or die(mysqli_error());
	alert('Schedule Resend Successful');
	echo"<script>window.location = 'management.php';</script>";
?>
