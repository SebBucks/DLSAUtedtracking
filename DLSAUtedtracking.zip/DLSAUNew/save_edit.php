<?php
session_start();
	require_once 'admin/conn.php';

function alert($msg) {
    echo "<script type='text/javascript'>alert('$msg');</script>";
}

	if(ISSET($_POST['edit'])){	
	    $starttime = $_POST['starthour']. ":" . $_POST['startmin'];
		$endtime = $_POST['endhour']. ":" . $_POST['endmin'];
		$classtype = $_POST['timetype'];
			if($classtype == 'C')
			{
			$timetype = 'Consultation';
			}elseif($classtype == 'OC')
			{
			$timetype = 'Off-Campus';
			}elseif($classtype == 'OH')
			{
			$timetype = 'Office Hours';
			}
		$daytype = $_POST['daytype'];
		  if(empty($daytype)) 
		  {
			//echo("no day(s) selected");
		  } 
		  else
		  {
		  $ok = '';
		  	$subj = $_POST['subjcode'];
			$daycount = count($_POST['daytype']);
			$finaldaytype = "";
			//echo("You selected $daycount day(s): ");
			
			$counter= 1;
			$Subjcode = $classtype . $counter;

			$result=mysqli_query($conn,"select * from timetable where Idnum = '$_SESSION[faculty]' AND classtype = '$classtype'")or die(mysqli_error());
				while($row=mysqli_fetch_array($result))
				{	
					if ($Subjcode == $row['SubjectCode']  )
					{
					
					$counter= $counter + 1;
					$Subjcode =  $classtype . $counter;
					}
				}
			for($i=0; $i < $daycount; $i++)
			{
			//echo '</br>' . $daytype[$i];
			 $finalday = $finalday . $daytype[$i] . ", ";
			  $finaldaytype = rtrim($finalday,",");
				$result=mysqli_query($conn,"select * from timetable where Idnum = '$_SESSION[faculty]' AND day like '%$daytype[$i]%'")or die(mysqli_error());
				if(mysqli_num_rows($result)== 0){
    				 	if (strtotime($starttime) >= strtotime($endtime))
    					{
    						$ok = 'start time is greater that end time';
    						break;
    					}
    					else
    					{
    					 $ok = 'ok';
    					}
				}else{
    				while($row=mysqli_fetch_array($result))
    				{
    				 	if (strtotime($starttime) >= strtotime($endtime))
    					{
    						$ok = 'start time is greater that end time';
    						break;
    					}
    					else
    					{
    						if (strtotime($starttime) >= strtotime($row['StartTime']) and strtotime($starttime) < strtotime($row['EndTime']))
    						{
    							if($subj == $row['SubjectCode'])
    							{
    								$ok = 'ok';
    							}else
    							{
    							$ok = "Invalid time". $Subjcode." ".$timetype. " "
    							        . $starttime. " - " .$endtime. " " . $finaldaytype.
    							        "Conflict with ". $row['SubjectCode']." ".$row['Description']. " "
    							        . $row['StartTime']. " - " .$row['EndTime']. " " . $row['Day'];
    							break;
    							}		
    						}else
    						{
    							if (strtotime($endtime) > strtotime($row['StartTime']) and strtotime($endtime) <= strtotime($row['EndTime']))
    							{
    								if($subj == $row['SubjectCode'])
    									{
    									$ok = 'ok';
    									}else
    									{
    									$ok = "Invalid time". $Subjcode." ".$timetype. " "
    							        . $starttime. " - " .$endtime. " " . $finaldaytype.
    							        "Conflict with ". $row['SubjectCode']." ".$row['Description']. " "
    							        . $row['StartTime']. " - " .$row['EndTime']. " " . $row['Day'];
    									break;
    									}
    							}else
    							{
    								$ok = 'ok';				
    							}
    						}	
    					}
    				}
				}
			 }
		  }	
		//echo '</br>'. $classtype;
		//echo '</br>'. $starttime;
		//echo '</br>'. $endtime;
		//echo '</br> verdict: '. $ok;	
	
		
		if($ok != 'ok')
		{
		echo "<script>alert('".$starttime.$endtime. $ok ."');</script>";
		echo "<script>window.location = 'profile.php'</script>";
		}else
		{
	

		mysqli_query($conn, "UPDATE `timetable` SET SubjectCode = '$Subjcode', Description = '$timetype', Section = 'N/A', StartTime = '$starttime', 
							EndTime = '$endtime', Day = '$finaldaytype', daycount = '$daycount', ClassType = '$classtype'
							Where Idnum = '$_SESSION[faculty]' and SubjectCode = '$subj'") or die(mysqli_error());
							
		echo "<script>alert('Successfully Updated!');</script>";	
		echo "<script>window.location = 'profile.php'</script>";
		
	
	
		}
		
	}
?>