<script type="text/javascript">
$(function(){
    var requiredCheckboxes = $('.days :checkbox[required]');
    requiredCheckboxes.change(function(){
        if(requiredCheckboxes.is(':checked')) {
            requiredCheckboxes.removeAttr('required');
        } else {
            requiredCheckboxes.attr('required', 'required');
        }
    });
});
</script>

<div class="modal fade" id="edit_modal<?php echo $fetch['SubjectCode'];?>" aria-hidden="true">
	<div class="modal-dialog modal-dialog-centered">		
        <div class="modal-content"> 
          <form method="POST" action="save_edit.php">
            <div class="modal-header"> 
          <h4 class="modal-title">Update Time</h4>
        </div>
        
      <div class="modal-body"> 
        <div class="col-md-6"> 
          <div class="form-group">
		  	<input type = "hidden" name = "subjcode" value ="<?php echo $fetch['SubjectCode'];?>">	   
            <p>Type:</p>
			<?php 
			$Consult = '';
			$OffCamp = '';
			$Office = '';
			if($fetch['ClassType'] == 'C'){
			    $Consult = 'checked';
			}elseif($fetch['ClassType'] == 'OC'){
			    $OffCamp = 'checked';
			}elseif($fetch['ClassType'] == 'OH'){
			    $Office = 'checked';
			}
			       ?>
  				<input type="radio" id="Consultation" name="timetype" value="C" required="required" <?php echo $Consult ?>>
 					 <label for="Consultation">Consultation</label><br>
 
  				<input type="radio" id="Off-Campus" name="timetype" value="OC" required="required" <?php echo $OffCamp?>>
  					<label for="Off-Campus">Off-Campus</label><br>
  				<input type="radio" id="OfficeHours" name="timetype" value="OH" required="required" <?php echo $Office?>>
 					 <label for="OfficeHours">Office Hours</label>
          </div>
		  <div class="form-group days"> 
            <p>Days:</p>
            <?php
            $M='';
            $T='';
            $W='';
            $H='';
            $F='';
            $S='';
            
            if(preg_match("/M/",$fetch['Day'])){
            $M = 'Checked';
            }
            if(preg_match("/T/",$fetch['Day'])){
            $T = 'Checked';
            }
            if(preg_match("/W/",$fetch['Day'])){
            $W = 'Checked';
            }
            if(preg_match("/H/",$fetch['Day'])){
            $H = 'Checked';
            }
            if(preg_match("/F/",$fetch['Day'])){
            $F = 'Checked';
            }
            if(preg_match("/S/",$fetch['Day'])){
            $S = 'Checked';
            }
            ?>
  				<input type="checkbox" id="Monday" name="daytype[]" value="M" <?php echo $M?>>
 					 <label for="Monday">Monday</label><br>
  				<input type="checkbox" id="Tuesday" name="daytype[]" value="T" <?php echo $T?>>
 					 <label for="Tuesday">Tuesday</label><br>
  				<input type="checkbox" id="Wednesday" name="daytype[]" value="W" <?php echo $W?>>
 					 <label for="Wednesday">Wednesday</label><br>
				<input type="checkbox" id="Thursday" name="daytype[]" value="H" <?php echo $H?>>
 					 <label for="Thursday">Thursday</label><br>
			    <input type="checkbox" id="Friday" name="daytype[]" value="F" <?php echo $F?>>
 					 <label for="Friday">Friday</label><br>
 				<input type="checkbox" id="Saturday" name="daytype[]" value="S"<?php echo $S?> >
 					 <label for="Saturday">Saturday</label><br>	 
          </div>
          <div class="form-group"> 
          
         
          
            <label>Start Time</label>
			
		<?php 
		$startexplode = explode(":",$fetch['StartTime']);
		$startexplodehour = $startexplode[0];
		$startexplodemin = $startexplode[1];
		 //echo $startexplodehour;
		 //echo '</br>';
		 //echo $startexplodemin;
		?>
          <select name="starthour" id="starthour">
		 <?php 
		 $s1 = $s2 = $s3 = '';
		 $p = [];
		 
		 if($startexplodehour == '07'){
		 $s1 = 'selected="selected"';
		 }
		 if($startexplodehour == '08'){
		 $s2 = 'selected="selected"';
		 }
		 if($startexplodehour == '09'){
		 $s3 = 'selected="selected"';
		 }
		
		 ?>
  				 <option value="07"<?php echo $s1?>>07</option>
				 <option value="08"<?php echo $s2?>>08</option>
				 <option value="09"<?php echo $s3?>>09</option>
		<?php 
		 for($i=10; $i<=19; $i++){
		 $pcount = $i -10;
		 if($startexplodehour == $i){
		 $p[$pcount] = 'selected="selected"';
		 }else{
		 $p[$pcount] = ' ';
		 }
		 } 
		 for($i=10; $i<=19; $i++){
		 $pcount = $i -10;
			echo '<option value="'.$i.'" '.$p[$pcount].'>'.$i.'</option>';
		 } 
	    ?>
				
			</select>
			:
			<select name="startmin" id="startmin">
			<?php 
		 $s1 = $s2 = $s3 = $s4 = $s5 = $s6 = $s7 = $s8 =$s9 = $s10 ='';
		 $p = [];
		 if($startexplodemin == '00'){
		 $s1 = 'selected="selected"';
		 }
		 if($startexplodemin == '01'){
		 $s2 = 'selected="selected"';
		 }
		 if($startexplodemin == '02'){
		 $s3 = 'selected="selected"';
		 }
		 if($startexplodemin == '03'){
		 $s4 = 'selected="selected"';
		 }
		 if($startexplodemin == '04'){
		 $s5 = 'selected="selected"';
		 }
		 if($startexplodemin == '05'){
		 $s6 = 'selected="selected"';
		 }
		 if($startexplodemin == '06'){
		 $s7 = 'selected="selected"';
		 }
		 if($startexplodemin == '07'){
		 $s8 = 'selected="selected"';
		 }
		 if($startexplodemin == '08'){
		 $s9 = 'selected="selected"';
		 }
		 if($startexplodemin == '09'){
		 $s10 = 'selected="selected"';
		 }
		 ?>
  				 <option value="00" <?php echo $s1?>>00</option>
				 <option value="01" <?php echo $s2?>>01</option>
				 <option value="02" <?php echo $s3?>>02</option>
				 <option value="03" <?php echo $s4?>>03</option>
				 <option value="04" <?php echo $s5?>>04</option>
				 <option value="05" <?php echo $s6?>>05</option>
				 <option value="06" <?php echo $s7?>>06</option>
				 <option value="07" <?php echo $s8?>>07</option>
				 <option value="08" <?php echo $s9?>>08</option>
				 <option value="09" <?php echo $s10?>>09</option>
				<?php 
				 for($i=10; $i<=60; $i++){
				 $pcount = $i -10;
				 if($startexplodemin == $i){
				 $p[$pcount] = 'selected="selected"';
				 }else{
				 $p[$pcount] = ' ';
				 }
				 } 
				 for($i=10; $i<=60; $i++){
				     $pcount = $i -10;
				 	echo '<option value="'.$i.'"'.$p[$pcount].'>'.$i.'</option>';
				 } 
				 ?>
			</select>
          </div>
          <div class="form-group"> 
            <label>End Time</label>
           <?php 
		$endexplode = explode(":",$fetch['EndTime']);
		$endexplodehour = $endexplode[0];
		$endexplodemin = $endexplode[1];
		 //echo $endexplodehour;
		 //echo '</br>';
		 //echo $endexplodemin;
		?>
          <select name="endhour" id="endhour">
		 <?php 
		 $s1 = $s2 = $s3 = '';
		 $p = [];
		 
		 if($endexplodehour == '07'){
		 $s1 = 'selected="selected"';
		 }
		 if($endexplodehour == '08'){
		 $s2 = 'selected="selected"';
		 }
		 if($endexplodehour == '09'){
		 $s3 = 'selected="selected"';
		 }
		
		 ?>
  				 <option value="07"<?php echo $s1?>>07</option>
				 <option value="08"<?php echo $s2?>>08</option>
				 <option value="09"<?php echo $s3?>>09</option>
		<?php 
		 for($i=10; $i<=19; $i++){
		 $pcount = $i -10;
		 if($endexplodehour == $i){
		 $p[$pcount] = 'selected="selected"';
		 }else{
		 $p[$pcount] = ' ';
		 }
		 } 
		 for($i=10; $i<=19; $i++){
		 $pcount = $i -10;
			echo '<option value="'.$i.'" '.$p[$pcount].'>'.$i.'</option>';
		 } 
	    ?>
				
			</select>
			:
			<select name="endmin" id="endmin">
			<?php 
		 $s1 = $s2 = $s3 = $s4 = $s5 = $s6 = $s7 = $s8 =$s9 = $s10 ='';
		 $p = [];
		 if($endexplodemin == '00'){
		 $s1 = 'selected="selected"';
		 }
		 if($endexplodemin == '01'){
		 $s2 = 'selected="selected"';
		 }
		 if($endexplodemin == '02'){
		 $s3 = 'selected="selected"';
		 }
		 if($endexplodemin == '03'){
		 $s4 = 'selected="selected"';
		 }
		 if($endexplodemin == '04'){
		 $s5 = 'selected="selected"';
		 }
		 if($endexplodemin == '05'){
		 $s6 = 'selected="selected"';
		 }
		 if($endexplodemin == '06'){
		 $s7 = 'selected="selected"';
		 }
		 if($endexplodemin == '07'){
		 $s8 = 'selected="selected"';
		 }
		 if($endexplodemin == '08'){
		 $s9 = 'selected="selected"';
		 }
		 if($endexplodemin == '09'){
		 $s10 = 'selected="selected"';
		 }
		 ?>
  				 <option value="00" <?php echo $s1?>>00</option>
				 <option value="01" <?php echo $s2?>>01</option>
				 <option value="02" <?php echo $s3?>>02</option>
				 <option value="03" <?php echo $s4?>>03</option>
				 <option value="04" <?php echo $s5?>>04</option>
				 <option value="05" <?php echo $s6?>>05</option>
				 <option value="06" <?php echo $s7?>>06</option>
				 <option value="07" <?php echo $s8?>>07</option>
				 <option value="08" <?php echo $s9?>>08</option>
				 <option value="09" <?php echo $s10?>>09</option>
				<?php 
				 for($i=10; $i<=60; $i++){
				 $pcount = $i -10;
				 if($endexplodemin == $i){
				 $p[$pcount] = 'selected="selected"';
				 }else{
				 $p[$pcount] = ' ';
				 }
				 } 
				 for($i=10; $i<=60; $i++){
				     $pcount = $i -10;
				 	echo '<option value="'.$i.'"'.$p[$pcount].'>'.$i.'</option>';
				 } 
				 ?>
			</select>
          </div>
      </div>
        </div>
        <div style="clear:both;"></div>
        <div class="modal-footer"> 
          <button type="button" class="btn btn-danger" data-dismiss="modal"><span class="glyphicon glyphicon-remove"></span> 
          Close</button>
          <button name="edit" id="edit" class="btn btn-success" ><span class="glyphicon glyphicon-save"></span> 
          Update</button>
        </div>
          </form>
        </div>
	</div>
</div>
					