<script type="text/javascript">
$(function(){
    var requiredCheckboxes = $('.days :checkbox[required]');
    requiredCheckboxes.change(function(){
        if(requiredCheckboxes.is(':checked')) {
            requiredCheckboxes.removeAttr('required');
        } else {
            requiredCheckboxes.attr('required', 'required');
        }
    });
});
</script>

<div class="modal fade" id="form_addtime" aria-hidden="true">
		<div class="modal-dialog modal-dialog-centered">
			
    <div class="modal-content"> 
      <form method="POST" action="save_time.php">
        <div class="modal-header"> 
          <h4 class="modal-title">Add Time</h4>
        </div>
        
      <div class="modal-body"> 
        <div class="col-md-6"> 
          <div class="form-group"> 
            <p>Type:</p>
  				<input type="radio" id="Consultation" name="timetype" value="C" required="required">
 					 <label for="Consultation">Consultation</label><br>
  				<input type="radio" id="Off-Campus" name="timetype" value="OC" required="required">
  					<label for="Off-Campus">Off-Campus</label><br>
  				<input type="radio" id="OfficeHours" name="timetype" value="OH" required="required">
 					 <label for="OfficeHours">Office Hours</label>
          </div>
		  <div class="form-group days">
            <p>Days:</p>
  				<input type="checkbox" id="Monday" name="daytype[]" value="M" required>
 					 <label for="Monday">Monday</label><br>
  				<input type="checkbox" id="Tuesday" name="daytype[]" value="T" required>
 					 <label for="Tuesday">Tuesday</label><br>
  				<input type="checkbox" id="Wednesday" name="daytype[]" value="W" required>
 					 <label for="Wednesday">Wednesday</label><br>
				<input type="checkbox" id="Thursday" name="daytype[]" value="H" required>
 					 <label for="Thursday">Thursday</label><br>
			    <input type="checkbox" id="Friday" name="daytype[]" value="F" required>
 					 <label for="Friday">Friday</label><br>
 				<input type="checkbox" id="Saturday" name="daytype[]" value="S" required>
 					 <label for="Saturday">Saturday</label><br>
          </div>
          <div class="form-group"> 
            <label>Start Time</label> 
          	<select name="starthour" id="starthour">
  				 <option value="07">07</option>
				 <option value="08">08</option>
				 <option value="09">09</option>
				<?php 
				 for($i=10; $i<=19; $i++){
				 	echo '<option value="'.$i.'">'.$i.'</option>';
				 } 
				 ?>
				
			</select>
			:
			<select name="startmin" id="startmin">
  				 <option value="00">00</option>
				 <option value="01">01</option>
				 <option value="02">02</option>
				 <option value="03">03</option>
				 <option value="04">04</option>
				 <option value="05">05</option>
				 <option value="06">06</option>
				 <option value="07">07</option>
				 <option value="08">08</option>
				 <option value="09">09</option>
				<?php 
				 for($i=10; $i<=60; $i++){
				 	echo '<option value="'.$i.'">'.$i.'</option>';
				 } 
				 ?>
			</select>
			
          </div>
          <div class="form-group"> 
            <label>End Time</label>
           <select name="endhour" id="endhour">
  				 <option value="07">07</option>
				 <option value="08">08</option>
				 <option value="09">09</option>
				 <?php 
				 for($i=10; $i<=19; $i++){
				 	echo '<option value="'.$i.'">'.$i.'</option>';
				 } 
				 ?>
			</select>
			:
			<select name="endmin" id="endmin">
  				 <option value="00">00</option>
				 <option value="01">01</option>
				 <option value="02">02</option>
				 <option value="03">03</option>
				 <option value="04">04</option>
				 <option value="05">05</option>
				 <option value="06">06</option>
				 <option value="07">07</option>
				 <option value="08">08</option>
				 <option value="09">09</option>
				<?php 
				 for($i=10; $i<=60; $i++){
				 	echo '<option value="'.$i.'">'.$i.'</option>';
				 } 
				 ?>
			</select>
          </div>
		  
      </div>
        </div>
        <div style="clear:both;"></div>
        <div class="modal-footer"> 
          <button type="button" class="btn btn-danger" data-dismiss="modal"><span class="glyphicon glyphicon-remove"></span> 
          Close</button>
          <button name="save" id="save" class="btn btn-success" ><span class="glyphicon glyphicon-save"></span> 
          Save</button>
        </div>
      </form>
    </div>
		</div>
	</div>