<?php
	session_start();
	require 'admin/conn.php';
	
	if(ISSET($_POST['login'])){
		$Idnum = $_POST['Idnum'];
		$passcode = $_POST['passcode'];
		
		$query = mysqli_query($conn, "SELECT * FROM `faculty` WHERE `Idnum` = '$Idnum' && `passcode` = '$passcode'") or die(mysqli_error());
		$fetch = mysqli_fetch_array($query);
		$row = $query->num_rows;
		
		if($row > 0){
			$_SESSION['faculty'] = trim($fetch['Idnum']);
			$_SESSION['college'] = trim($fetch['College']);
			$_SESSION['dept'] = trim($fetch['Department']);
			if($fetch['management'] == 'No')
			{
			header("location:profile.php");
			}else if($fetch['management'] == 'Yes')
			{
			header("location:management.php");
			}
			
		}else{
			echo "<center><label class='text-danger'>Invalid username or password</label></center>";
		}
	}
?>