<?php
session_start();
include 'admin/conn.php';

if(isset($_POST["import"])){
 
 $idnum = $_POST['load'];
	 $filename=$_FILES["file"]["tmp_name"];
		
 
	if ($_FILES['file']['size'] == 0)
		{
 		 echo "<script type=\"text/javascript\">
							alert(\"No File Uploaded:Please Upload a CSV File.\");
							window.location = \"progchair_profile.php\"
						</script>";
		}else{
		
				
		 if($_FILES["file"]["size"] > 0)
		 {	
		 						
		  	$file = fopen($filename, "r");
			fgets($file);
			mysqli_query($conn, "DELETE from timetable where Idnum = '$idnum'") or die(mysqli_error());
			mysqli_query($conn, "UPDATE approval set submitted = '--', progsub = '--', deansub = '--', regsub = '--', hrsub = '--', vcarsub = '--', reject = '--', progchair = '--' where IDnum = '$idnum'") or die(mysqli_error());
	         while (($emapData = fgetcsv($file, 10000, ",")) !== FALSE)
	         {
				 if (empty($emapData)) {
        			break;
   			 	}				
	          //It wiil insert a row to our subject table from our csv file`
				
	           $result = mysqli_query( $conn,"INSERT into timetable (`SubjectCode`, `Description`, `Section`, `StartTime`,`EndTime`, `Day`, `daycount`,`Units`,`ClassType`,`Idnum`) 
	            	values('$emapData[0]','$emapData[1]','$emapData[2]','$emapData[3]','$emapData[4]','$emapData[5]','$emapData[6]','$emapData[7]','$emapData[8]','$idnum')") or die(mysqli_error($conn));
	         //we are using mysql_query function. it returns a resource on true else False on error
	           
				if(! $result )
				{
					echo "<script type=\"text/javascript\">
							alert(\"Invalid File:Please Upload CSV File.\");
							
						</script>";
 
				}
 
	         }
			
	         fclose($file);
			 
	         
			 //throws a message if data successfully imported to mysql database from excel file
			 $query = mysqli_query($conn, "SELECT * FROM programchair WHERE Idnum = '$idnum' ") or die(mysqli_error());
			 $fetch = mysqli_fetch_array($query);
			 $facultyid = $fetch['IDnum'];
			 if($faculty <> NULL){
	         echo "<script type=\"text/javascript\">
						alert(\"CSV File has been successfully Imported.\");
						window.location = \"progchair_profile.php\"
					</script>";
			 }else{
			     echo "<script type=\"text/javascript\">
						alert(\"CSV File has been successfully Imported.\");
						window.location = \"profile.php\"
					</script>";
			 }
 
 
			 //close of connection
			mysqli_close($conn); 
 
 
 
		 }
		}
	}	 
?>	