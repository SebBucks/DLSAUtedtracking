 <h4 style="color:red;">Progress Bar</h4>
 <?php 
 $status = '';
 $query = mysqli_query($conn, "SELECT * FROM `approval` WHERE `IDnum` = '$_SESSION[faculty]'") or die(mysqli_error());
			$fetch = mysqli_fetch_array($query);
			?>
<div class="container">
      <ul class="myprogressbar">
	  <?php
	  if($fetch['submitted'] == 'ok'){
	  $status = 'active';
       echo '<li class="'.$status.'">Submitted</li>';
		}else{
		echo '<li>Submitted</li>';
		}
	 
	  if($fetch['progsub'] == 'ok'){
	  $status = 'active';
       echo '<li class="'.$status.'">Program Chair</li>';
		}else{
		echo '<li>Program Chair</li>';
		}
	
	  if($fetch['deansub'] == 'ok'){
	  $status = 'active';
       echo '<li class="'.$status.'">Dean</li>';
		}else{
		echo '<li>Dean</li>';
		}
		
     
	  if($fetch['regsub'] == 'ok'){
	  $status = 'active';
       echo '<li class="'.$status.'">Registrar</li>';
		}else{
		echo '<li>Registrar</li>';
		}
		
	  if($fetch['hrsub'] == 'ok'){
	  $status = 'active';
       echo '<li class="'.$status.'">HR head</li>';
		}else{
		echo '<li>HR head</li>';
		}
		
		 if($fetch['vcarsub'] == 'ok'){
	  $status = 'active';
       echo '<li class="'.$status.'">VCAR</li>';
		}else{
		echo '<li>VCAR</li>';
		}
		?>
	
	 
      </ul>
</div>