<h3>Update Loads</h3>
<table id= "table2"  tableclass="table table-bordered">
<?php 
$idcheck = '';
$department = ''; 
$facdept = '';
?>
<?php
	$idnum = $_SESSION['faculty'];
			$query = mysqli_query($conn, "SELECT * FROM programchair WHERE IDnum = '$idnum' ") or die(mysqli_error());				
			while($fetch = mysqli_fetch_array($query)){
				$department = trim($fetch['Department']);
				}
						?>
        <thead>
          <tr> 
            <th>ID number</th>
			<th>Name</th>
			<th>Upload New Load Set</th>
			</tr>			
        </thead>
        <tbody id = "tablebody" >
		<?php
			$query = mysqli_query($conn, "SELECT * FROM approval") or die(mysqli_error());				
			while($fetch = mysqli_fetch_array($query)){
				$idcheck = $fetch['IDnum'];
				$approvalcheck = $fetch['progsub'];					
						?>
		
		<?php 
	//	if($approvalcheck == 'ok'){
				//echo '<td></td><td></td><td></td>';
				//echo 'test1';
	//			}else{	
		?>
		 <?php
			$query1 = mysqli_query($conn, "SELECT * FROM faculty WHERE Idnum = '$idcheck' AND Department = '$department'") or die(mysqli_error());				
			while($fetch1 = mysqli_fetch_array($query1)){
				//$facdept = trim($fetch1['Department']);
				//echo $idcheck;
				 //echo $department;
	  			 //echo $facdept;
					//if ($department == $facdept){
						?>
		<tr class="del_user<?php echo $idcheck?>">
         <td><?php echo $idcheck?></td>
		 <td><?php echo $fetch1['firstname'] . " " . $fetch1['lastname']?></td>   	
		 <td><button class="btn btn-success" data-toggle="modal" data-target="#updater<?php echo $idcheck?>"><span class="glyphicon glyphicon-save"></span>
		 Update Loads</button></td>
		 <?php
		 //echo 'test2';
			//}else
			//echo '<td></td><td></td><td></td>';
		//	echo 'test3';
		?>
		</tr>
		<?php 
		     include 'progchair_load_updater_modal.php';
		}
	//}
}
		?> 
	    </tbody>
      </table>