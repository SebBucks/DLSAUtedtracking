<br><br>
 <?php $grandtotal = 0;
 ?>
	<table class="table table-bordered">
	<tr>
	    
    <th colspan="3"><h4 style="color:red;">Summary</h4></th>
 	 </tr>
 	 <tr>
	    <td><h4>Load Type</h4></td>
	    <td><h4>Hours</h4></td>
	    <td><h4>Remarks</h4></td>
 	 </tr>
 		<tr>
 		    <?php
	    $summarytotal = '';
	    	
	   $result=mysqli_query($conn,"select * from currentsem where Term_ID = '1'")or die(mysqli_error());
	   $row=mysqli_fetch_array($result);
	   $partquery=mysqli_query($conn,"select * from faculty where Idnum = '$_SESSION[faculty]'")or die(mysqli_error());
	   $partfetch=mysqli_fetch_array($partquery);
	  if($partfetch['WorkStatus'] == 'PARTTIME'){
	    $summarytotal = 16; 
	  }else{
	  if($row['Term'] == 1)
	  {
	    $summarytotal = 24;
	  }else{
	    $summarytotal = 20; 
	  }
	  }
	    ?>
    		<td>Regular Load (R) <?php echo '<font color=blue> ('.$summarytotal.' hours per week)';?></td>
   			<td ><?php 
			
			$query=mysqli_query($conn,"select * from faculty where Idnum = '$_SESSION[faculty]'")or die(mysqli_error());
	 		$fetch=mysqli_fetch_array($query);
	 		$workstatus = $fetch['WorkStatus'];
			$starttime='';
			$endtime='';
			$output='';
			$total=0;
	  $result=mysqli_query($conn,"select * from timetable where IDnum = '$_SESSION[faculty]' AND classtype = 'R'")or die(mysqli_error());
	  while($row=mysqli_fetch_array($result))
	  {
	  $starttime= decimalHours($row['StartTime']);
	  $endtime= decimalHours($row['EndTime']);
	  $output = $endtime-$starttime;
	  $output = $output * $row['daycount'];
	  $total = $total + $output;				
	  }
	  echo round($total,2);
	  $grandtotal = $grandtotal + $total;
	  $integer = (int)$total;
	  	
	  ?>
	  </td>
	  <td><?php 
	   $result=mysqli_query($conn,"select * from currentsem where Term_ID = '1'")or die(mysqli_error());
	   $row=mysqli_fetch_array($result);
	  if($row['Term'] == 1)
	  {
		if($workstatus == "PARTTIME"){
				if($integer > 16)
				{
				echo '<font color=red>Invalid Regular Load';
				}
		 }else{		  	
				if($integer <> 24)
				{
				echo '<font color=red>Invalid Regular Load';
				}else
				{
				echo '<font color=green>Ok';
				}
		 }	
	 }else{
	 	if($workstatus == "PARTTIME"){
				if($integer >= 16)
				{
				echo '<font color=red>Invalid Regular Load';
				}else
				{
				echo '<font color=green>Ok';
				}
		 }else{	
				if($integer <> 20)
				{
				echo '<font color=red>Invalid Regular Load';
				}else
				{
				echo '<font color=green>Ok';
				}
		 }	
	 }
	  ?></td>
 		</tr>
  		<tr>
  		    
    		<td>Overload(O)</td>
    		<td><?php 
			$starttime='';
			$endtime='';
			$output='';
			$total=0;
	  $result=mysqli_query($conn,"select * from timetable where IDnum = '$_SESSION[faculty]' AND classtype = 'O'")or die(mysqli_error());
	  while($row=mysqli_fetch_array($result))
	  {
	  $starttime= decimalHours($row['StartTime']);
	  $endtime= decimalHours($row['EndTime']);
	  $output = $endtime-$starttime;
	  $output = $output * $row['daycount'];
	  $total = $total + $output;				
	  }
	  echo round($total,2);
	  $grandtotal = $grandtotal + $total;
	  $integer = (int)$total;	
	  ?></td>
	  <td><?php  
	  if($workstatus <> "PARTTIME"){
	  	if($integer > 8)
		{
		echo '<font color=red>Invalid Overtime Load';
		}else
		{
		echo '<font color=green>Ok';
		}
	  }
	  ?></td>
  		</tr>
		<tr>
    		<td>Requested tutorial (RT)</td>
    		<td><?php 
			$starttime='';
			$endtime='';
			$output='';
			$total=0;
	  $result=mysqli_query($conn,"select * from timetable where IDnum = '$_SESSION[faculty]' AND classtype = 'RT'")or die(mysqli_error());
	  while($row=mysqli_fetch_array($result))
	  {
	  $starttime= decimalHours($row['StartTime']);
	  $endtime= decimalHours($row['EndTime']);
	  $output = $endtime-$starttime;
	  $output = $output * $row['daycount'];
	  $total = $total + $output;				
	  }
	  echo round($total,2);
	  $grandtotal = $grandtotal + $total;
	  $integer = (int)$total;	
	  ?></td>
	  		<td></td>
  		</tr>
		<tr>
    		<td>Converted tutorial (CT)</td>
    		<td><?php 
			$starttime='';
			$endtime='';
			$output='';
			$total=0;
	  $result=mysqli_query($conn,"select * from timetable where IDnum = '$_SESSION[faculty]' AND classtype = 'CT'")or die(mysqli_error());
	  while($row=mysqli_fetch_array($result))
	  {
	  $starttime= decimalHours($row['StartTime']);
	  $endtime= decimalHours($row['EndTime']);
	  $output = $endtime-$starttime;
	  $output = $output * $row['daycount'];
	  $total = $total + $output;				
	  }
	  echo round($total,2);
	  $grandtotal = $grandtotal + $total;
	  $integer = (int)$total;	
	  ?></td>
	  		<td></td>
  		</tr>
  		<?php
	    $summarytotal = '6';
	    ?>
		<tr>
    		<td>Consultation (C) <?php
    		if($workstatus <> "PARTTIME"){
    		echo '<font color=blue> ('.$summarytotal.' hours per week)';
    		}
    		?>
    		</td>
    		<td><?php 
			$starttime='';
			$endtime='';
			$output='';
			$total=0;
	  $result=mysqli_query($conn,"select * from timetable where IDnum = '$_SESSION[faculty]' AND classtype = 'C'")or die(mysqli_error());
	  while($row=mysqli_fetch_array($result))
	  {
	  $starttime= decimalHours($row['StartTime']);
	  $endtime= decimalHours($row['EndTime']);
	  $output = $endtime-$starttime;
	  $output = $output * $row['daycount'];
	  $total = $total + $output;				
	  }
	  echo round($total,2);
	  $grandtotal = $grandtotal + $total;
	  $integer = (int)$total;	
	  ?></td>
	  <td><?php 
	  if($workstatus <> "PARTTIME"){
	  if($integer == 6)
	  {
	  echo '<font color=green>Ok';
	  }else
	  {
	  echo '<font color=red>Consultation Overload/Underload';
	  }
	  }
	  ?></td>
  		</tr>
  		<?php
	    $summarytotal = '';
	     $result=mysqli_query($conn,"select * from currentsem where Term_ID = '1'")or die(mysqli_error());
	   $row=mysqli_fetch_array($result);
	  if($row['Term'] == 1)
	  { 
	   $summarytotal = 2.5;  
	  }else{
	   $summarytotal = 5.5;
	  }
	    ?>
		<tr>
    		<td>Off-Campus (OC)
    		<?php
    		if($workstatus <> "PARTTIME"){
    		echo '<font color=blue> ('.$summarytotal.' hours per week)';
    		}
    		?>
    		</td>
    		<td><?php 
			$starttime='';
			$endtime='';
			$output='';
			$total=0;
	  $result=mysqli_query($conn,"select * from timetable where IDnum = '$_SESSION[faculty]' AND classtype = 'OC'")or die(mysqli_error());
	  while($row=mysqli_fetch_array($result))
	  {
	  $starttime= decimalHours($row['StartTime']);
	  $endtime= decimalHours($row['EndTime']);
	  $output = $endtime-$starttime;
	  $output = $output * $row['daycount'];
	  $total = $total + $output;				
	  }
	  echo round($total,2);
	  $grandtotal = $grandtotal + $total;
	  $integer = $total;	
	  ?></td>
	  <td><?php 
	   $result=mysqli_query($conn,"select * from currentsem where Term_ID = '1'")or die(mysqli_error());
	   $row=mysqli_fetch_array($result);
	  if($workstatus <> "PARTTIME"){
	  if($row['Term'] == 1)
	  {
	  	if($integer <> '2.5')
	  	{
		echo '<font color=red>Off-Campus Overload/Underload';
		}
	  	else
		{
		echo '<font color=green>Ok';
		}	
	  }else
	  {
	  	if($integer <> '5.5')
	  	{
		echo '<font color=red>Off-Campus Overload/Underload';
		}
	  	else
		{
		echo '<font color=green>Ok';
		}	
	  }
	  }
	  ?></td>
  		</tr>
  		<?php
	    $summarytotal = '';
	     $result=mysqli_query($conn,"select * from currentsem where Term_ID = '1'")or die(mysqli_error());
	   $row=mysqli_fetch_array($result);
	  if($row['Term'] == 1)
	  {
	    $summarytotal = 7.5;
	  }else{
	    $summarytotal = 8.5; 
	  }
	    ?>
		<tr>
    		<td>Office Hours (OH)
    		<?php
    		if($workstatus <> "PARTTIME"){
    		echo '<font color=blue> ('.$summarytotal.' hours per week)';
    		}
    		?>
    		</td>
    		<td><?php 
			$starttime='';
			$endtime='';
			$output='';
			$total=0;
	  $result=mysqli_query($conn,"select * from timetable where IDnum = '$_SESSION[faculty]' AND classtype = 'OH'")or die(mysqli_error());
	  while($row=mysqli_fetch_array($result))
	  {
	  $starttime= decimalHours($row['StartTime']);
	  $endtime= decimalHours($row['EndTime']);
	  $output = $endtime-$starttime;
	  $output = $output * $row['daycount'];
	  $total = $total + $output;				
	  }
	  echo round($total,2);
	  $grandtotal = $grandtotal + $total;
	  $integer = $total;	
	  ?></td>
	  <td><?php 
	   $result=mysqli_query($conn,"select * from currentsem where Term_ID = '1'")or die(mysqli_error());
	   $row=mysqli_fetch_array($result);
	  if($workstatus <> "PARTTIME"){
	  if($row['Term'] == 1)
	  {
	  	if($integer == 7.5)
	 	{
		echo '<font color=green>Ok';
		}
	  	else
		{
		echo '<font color=red>Office Hours Overload/Underload';
		}	
	  }else
	  {
	  if($integer == 8.5)
	 	{
		echo '<font color=green>Ok';
		}
	  	else
		{
		echo '<font color=red>Office Hours Overload/Underload';
		}	
	  }
	  }
	  ?></td>
  		</tr>
		<tr>
    		<td>Total</td>
    		<td><?php 	
	  echo round($grandtotal,2);
	  $grandinteger = (int)$grandtotal;
	   $_SESSION['submitnum'] = $grandinteger;	
	  ?></td>
	  <td><?php 
	  if($workstatus == "PARTTIME"){
				if($grandinteger >= 40 )
				{
				echo '<font color=red>Overload';
				}
		 }else{	
			  if($grandinteger == 40)
			  {
			  echo '<font color=green>Ok';
			  }else
			  {
			  echo '<font color=red>Overload/Underload';
			  }  
		}
	   ?></td>
  		</tr>
  	</table>

	