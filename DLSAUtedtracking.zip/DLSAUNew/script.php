<script src = "admin/js/jquery-3.2.1.min.js"></script>
<script src = "admin/js/bootstrap.js"></script>
<script src = "admin/js/jquery.dataTables.js"></script>	
<script type = "text/javascript">
	$(document).ready(function() {
		$('#table').DataTable();
	} );
	$(document).ready(function() {
		$('#table2').DataTable();
	} );
	$(document).ready(function() {
		$('#table3').DataTable();
	} );
	$(document).ready(function() {
		$('#table4').DataTable();
	} );
	$(document).ready(function() {
		$('#table5').DataTable();
	} );
	$(document).ready(function() {
		$('#table6').DataTable();
	} );
</script>
	