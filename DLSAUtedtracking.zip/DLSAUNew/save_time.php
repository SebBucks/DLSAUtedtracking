<?php
session_start();
	require_once 'admin/conn.php';

function alert($msg) {
    echo "<script type='text/javascript'>alert('$msg');</script>";
}

	if(ISSET($_POST['save'])){
	    //echo $_SESSION['faculty'];
	    $starttime = $_POST['starthour']. ":" . $_POST['startmin'];
		$endtime = $_POST['endhour']. ":" . $_POST['endmin'];
		$classtype = $_POST['timetype'];
			if($classtype == 'C')
			{
			$timetype = 'Consultation';
			}elseif($classtype == 'OC')
			{
			$timetype = 'Off-Campus';
			}elseif($classtype == 'OH')
			{
			$timetype = 'Office Hours';
			}
		$daytype = $_POST['daytype'];
		//echo $_SESSION['faculty'];
		if(empty($daytype)) 
		{
		//echo("no day(s) selected");
		} 
		else
	    {
		  $ok = '';
			$daycount = count($_POST['daytype']);
			$finaldaytype = "";
			//echo("You selected $daycount day(s): ");
			
			$counter= 1;
			
			$Subjcode = $classtype . $counter;
			
			$result=mysqli_query($conn,"select * from timetable where Idnum = '$_SESSION[faculty]' AND ClassType = '$classtype'")or die(mysqli_error);
				while($row=mysqli_fetch_array($result))
				{	
					if ($Subjcode == $row['SubjectCode'])
					{
					$counter= $counter + 1;
					$Subjcode =  $classtype . $counter;
					}
				}
		    	
			for($i=0; $i < $daycount; $i++)
			{
			//echo '</br>' . $daytype[$i];
			 $finalday = $finalday . $daytype[$i] . ", ";
			 $finaldaytype = rtrim($finalday,",");
				$result=mysqli_query($conn,"select * from timetable where Idnum = '$_SESSION[faculty]' AND Day like '%$daytype[$i]%'")or die(mysqli_error());
				if(mysqli_num_rows($result)== 0){
				    
    				 	if (strtotime($starttime) >= strtotime($endtime))
    					{
    						$ok = 'start time is greater that end time';
    						break;
    					}
    					else
    					{
    					 $ok = 'ok';
    					}
    			
				}else{
    				while($row=mysqli_fetch_array($result))
    				{
    				 	if (strtotime($starttime) >= strtotime($endtime))
    					{
    						$ok = 'start time is greater that end time';
    						break;
    					}
    					else
    					{
    						if (strtotime($starttime) >= strtotime($row['StartTime']) and strtotime($starttime) < strtotime($row['EndTime']))
    						{
    							$ok = "Invalid time ". $Subjcode." ".$timetype. " "
    							        . $starttime. " - " .$endtime. " " . $finaldaytype.
    							        "Conflict with ". $row['SubjectCode']." ".$row['Description']. " "
    							        . $row['StartTime']. " - " .$row['EndTime']. " " . $row['Day'];
    							break;		
    						}else
    						{
    							if (strtotime($endtime) > strtotime($row['StartTime']) and strtotime($endtime) <= strtotime($row['EndTime']))
    							{
    							$ok = "Invalid time". $Subjcode." ".$timetype. " "
    							        . $starttime. " - " .$endtime. " " . $finaldaytype.
    							        "Conflict with ". $row['SubjectCode']." ".$row['Description']. " "
    							        . $row['StartTime']. " - " .$row['EndTime']. " " . $row['Day'];
    							break;
    							}else
    							{
    								$ok = 'ok';				
    							}
    						}	
    					}
    				}
			    }
			}
			
		  }	
		//echo '</br>'. $classtype;
		//echo '</br>'. $starttime;
		//echo '</br>'. $endtime;
		//echo '</br> verdict: '. $ok;	
		
		//echo 'test </br>' . $ok;
		if($ok != 'ok')
		{
		echo alert($ok);
		echo "<script>window.location = 'profile.php'</script>";
		}else
		{
		
		mysqli_query($conn, "INSERT INTO `timetable` (SubjectCode,Description,Section, StartTime, EndTime, Day, 
							 Daycount, Units, ClassType, Idnum) VALUES('$Subjcode', '$timetype', 'N/A', '$starttime', 
							'$endtime', '$finaldaytype', '$daycount', '0', '$classtype',
							'$_SESSION[faculty]')") or die(mysqli_error());
		
		echo "<script>alert('Successfully Added!');</script>";
	    echo "<script>window.location = 'profile.php'</script>";
		}
		
	}
?>