<h3>Printable Plotting Form</h3>
<table id= "table5"  tableclass="table table-bordered">

        <thead>
          <tr> 
            <th>ID number</th>
			<th>Name</th>
			<th>Print</th>
			</tr>			
        </thead>
        <tbody id = "tablebody" >
		<?php
			$query = mysqli_query($conn, "SELECT * FROM `faculty` WHERE management = 'No' AND Department = '$deptid'") or die(mysqli_error());				
			while($fetch = mysqli_fetch_array($query)){
			$idcheck = $fetch['Idnum'];
						?>
		<tr class="del_user<?php echo $idcheck?>">
		
         <td><?php echo $idcheck?></td>
		 <td><?php echo $fetch['firstname'] . " " . $fetch['lastname']?></td>   
	 	 <td><a href="print_load.php?id='<?php echo $idcheck?>'" target="_blank" class="btn btn-success"><span class="glyphicon glyphicon-edit">
	Print Plotting Form</a></td> 
		</tr>
	<?php }?>
	    </tbody>
      </table>