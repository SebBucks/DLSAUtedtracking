<p align="center">Summary: </p>
 <?php $grandtotal = 0;
 ?>
	<table class="center" width="50%" style="border: 1px solid black; border-collapse: collapse;">
 		<tr>
    		<td style="border: 1px solid black; border-collapse: collapse;">Regular Load (R)</td>
   			<td style="border: 1px solid black; border-collapse: collapse;"><?php 
			$starttime='';
			$endtime='';
			$output='';
			$total=0;
	  $result=mysqli_query($conn,"select * from timetable where IDnum = '$idtrim' AND classtype = 'R'")or die(mysqli_error());
	  while($row=mysqli_fetch_array($result))
	  {
	  $starttime= decimalHours($row['StartTime']);
	  $endtime= decimalHours($row['EndTime']);
	  $output = $endtime-$starttime;
	  $output = $output * $row['daycount'];
	  $total = $total + $output;				
	  }
	  echo $total;
	  $regular = $total;
	  $grandtotal = $grandtotal + $total;
	  $integer = (int)$total;
	  	
	  ?>
	  </td>
	  
 		</tr>
  		<tr>
    		<td style="border: 1px solid black; border-collapse: collapse;">Overload(O)</td>
    		<td style="border: 1px solid black; border-collapse: collapse;"><?php 
			$starttime='';
			$endtime='';
			$output='';
			$total=0;
	  $result=mysqli_query($conn,"select * from timetable where IDnum = '$idtrim' AND classtype = 'O'")or die(mysqli_error());
	  while($row=mysqli_fetch_array($result))
	  {
	  $starttime= decimalHours($row['StartTime']);
	  $endtime= decimalHours($row['EndTime']);
	  $output = $endtime-$starttime;
	  $output = $output * $row['daycount'];
	  $total = $total + $output;				
	  }
	  echo $total;
	  $overload = $total;
	  $grandtotal = $grandtotal + $total;
	  $integer = (int)$total;	
	  ?></td>
	 
  		</tr>
		<tr>
    		<td style="border: 1px solid black; border-collapse: collapse;">Requested tutorial (RT)</td>
    		<td style="border: 1px solid black; border-collapse: collapse;"><?php 
			$starttime='';
			$endtime='';
			$output='';
			$total=0;
	  $result=mysqli_query($conn,"select * from timetable where IDnum = '$idtrim' AND classtype = 'RT'")or die(mysqli_error());
	  while($row=mysqli_fetch_array($result))
	  {
	  $starttime= decimalHours($row['StartTime']);
	  $endtime= decimalHours($row['EndTime']);
	  $output = $endtime-$starttime;
	  $output = $output * $row['daycount'];
	  $total = $total + $output;				
	  }
	  echo $total;
	  $requested = $total;
	  $grandtotal = $grandtotal + $total;
	  $integer = (int)$total;	
	  ?></td>
	  		
  		</tr>
		<tr>
    		<td style="border: 1px solid black; border-collapse: collapse;">Converted tutorial (CT)</td>
    		<td style="border: 1px solid black; border-collapse: collapse;"><?php 
			$starttime='';
			$endtime='';
			$output='';
			$total=0;
	  $result=mysqli_query($conn,"select * from timetable where IDnum = '$idtrim' AND classtype = 'CT'")or die(mysqli_error());
	  while($row=mysqli_fetch_array($result))
	  {
	  $starttime= decimalHours($row['StartTime']);
	  $endtime= decimalHours($row['EndTime']);
	  $output = $endtime-$starttime;
	  $output = $output * $row['daycount'];
	  $total = $total + $output;				
	  }
	  echo $total;
	  $converted = $total;
	  $grandtotal = $grandtotal + $total;
	  $integer = (int)$total;	
	  ?></td>
	  	
  		</tr>
		<tr>
    		<td style="border: 1px solid black; border-collapse: collapse;">Consultation (C)</td>
    		<td style="border: 1px solid black; border-collapse: collapse;"> <?php 
			$starttime='';
			$endtime='';
			$output='';
			$total=0;
	  $result=mysqli_query($conn,"select * from timetable where IDnum = '$idtrim' AND classtype = 'C'")or die(mysqli_error());
	  while($row=mysqli_fetch_array($result))
	  {
	  $starttime= decimalHours($row['StartTime']);
	  $endtime= decimalHours($row['EndTime']);
	  $output = $endtime-$starttime;
	  $output = $output * $row['daycount'];
	  $total = $total + $output;				
	  }
	  echo $total;
	  $consultation = $total;
	  $grandtotal = $grandtotal + $total;
	  $integer = (int)$total;	
	  ?></td>
	  
  		</tr>
		<tr>
    		<td style="border: 1px solid black; border-collapse: collapse;">Off-Campus (OC)</td>
    		<td style="border: 1px solid black; border-collapse: collapse;"><?php 
			$starttime='';
			$endtime='';
			$output='';
			$total=0;
	  $result=mysqli_query($conn,"select * from timetable where IDnum = '$idtrim' AND classtype = 'OC'")or die(mysqli_error());
	  while($row=mysqli_fetch_array($result))
	  {
	  $starttime= decimalHours($row['StartTime']);
	  $endtime= decimalHours($row['EndTime']);
	  $output = $endtime-$starttime;
	  $output = $output * $row['daycount'];
	  $total = $total + $output;				
	  }
	  echo $total;
	  $offcampus = $total;
	  $grandtotal = $grandtotal + $total;
	  $integer = (int)$total;	
	  ?></td>
	  
  		</tr>
		<tr>
    		<td style="border: 1px solid black; border-collapse: collapse;">Office Hours (OH)</td>
    		<td style="border: 1px solid black; border-collapse: collapse;"><?php 
			$starttime='';
			$endtime='';
			$output='';
			$total=0;
	  $result=mysqli_query($conn,"select * from timetable where IDnum = '$idtrim' AND classtype = 'OH'")or die(mysqli_error());
	  while($row=mysqli_fetch_array($result))
	  {
	  $starttime= decimalHours($row['StartTime']);
	  $endtime= decimalHours($row['EndTime']);
	  $output = $endtime-$starttime;
	  $output = $output * $row['daycount'];
	  $total = $total + $output;				
	  }
	  echo $total;
	  $officehours = $total;
	  $grandtotal = $grandtotal + $total;
	  $integer = (int)$total;	
	  ?></td>
	 
  		</tr>
		<tr>
    		<td style="border: 1px solid black; border-collapse: collapse;">Total</td>
    		<td style="border: 1px solid black; border-collapse: collapse;"><?php 	
	  echo $grandtotal;
	  $grandinteger = (int)$grandtotal;	
	  ?></td>
	  
  		</tr>
  	</table>

	