<h3>Rejected Faculty Loads</h3>
<table id= "table"  tableclass="table table-bordered">
<?php 
$idcheck = '';
$department = ''; 
$facdept = '';
$approvalcheck = '';
?>
<?php
	$idnum = $_SESSION['faculty'];
			$query = mysqli_query($conn, "SELECT * FROM programchair WHERE IDnum = '$idnum' ") or die(mysqli_error());				
			while($fetch = mysqli_fetch_array($query)){
				$department = trim($fetch['Department']);
				}
						?>
        <thead>
          <tr> 
            <th>ID number</th>
			<th>Name</th>
			<th>Check Schedule</th>
			<th>Remarks</th>
			</tr>			
        </thead>
        <tbody id = "tablebody" >
		<?php
			$query = mysqli_query($conn, "SELECT * FROM approval WHERE progchair = 'ok' ") or die(mysqli_error());				
			while($fetch = mysqli_fetch_array($query)){
				$idcheck = $fetch['IDnum'];
				$approvalcheck = $fetch['progchair'];					
						?>
		<tr class="del_user<?php echo $idcheck?>">
		<?php }
		 if($approvalcheck == '--'){
				echo '<td></td><td></td><td></td><td></td>';
				//echo 'test1';
				}else{
				?>
		 <?php
			$query = mysqli_query($conn, "SELECT * FROM faculty WHERE Idnum = '$idcheck' ") or die(mysqli_error());				
			while($fetch = mysqli_fetch_array($query)){
				$facdept = trim($fetch['Department']);
				// echo $department;
	  			// echo $facdept;
					if ($department == $facdept){
						?>
         <td><?php echo $idcheck?></td>
		 <td><?php echo $fetch['firstname']?> <?php echo " " ?><?php echo $fetch['lastname']?></td>   
		
	 <td><a href="approval_view_progchair.php?id='<?php echo $fetch['Idnum']?>'" target="_blank" class="btn btn-warning"><span class="glyphicon glyphicon-edit">Check</a></td> 
		<?php 
		$query1 = mysqli_query($conn, "SELECT * FROM approval WHERE Idnum = '$idcheck' ") or die(mysqli_error());				
			while($fetch1 = mysqli_fetch_array($query1)){
		?>
		<td><?php echo $fetch1['reject'];?></td>
		<?php 
		}
		?>
		</tr>
		<?php 
			}else
			echo '<td></td><td></td><td></td><td></td>';
			//echo 'test2';
		}
	}
		?> 
	    </tbody>
      </table>