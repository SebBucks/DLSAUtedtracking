<!DOCTYPE html>
<?php 
	session_start();
	//require 'validator.php';
	require_once 'admin/conn.php'
?>
<?php
function fill_schoolyear($conn)  
 {  
      $output = '';  
      $sql = "SELECT * FROM tblschoolyr";  
      $result = mysqli_query($conn, $sql);  
	  $counter = 1;
      while($row = mysqli_fetch_array($result))  
      {  
	 		
           $output .= '<option value="'.$counter.'">'.$row["SchoolYear"].'</option>';  
		   echo(++$counter);
      }  
      return $output;  
 } 
 function fill_term($conn)  
 {  
      $output = '';  
      $sql = "SELECT * FROM tblterm";  
      $result = mysqli_query($conn, $sql);  
	  $counter = 1;
      while($row = mysqli_fetch_array($result))  
      {  
	 		
           $output .= '<option value="'.$counter.'">'.$row["Term"].'</option>';  
		   echo(++$counter);
      }  
      return $output;  
 }  
function decimalHours($time)
{
    $hms = explode(":", $time);
    return ($hms[0] + ($hms[1]/60) + ($hms[2]/3600));
}
function alert($msg) {
    echo "<script type='text/javascript'>alert('$msg');</script>";
}

?>
<html lang = "en">
	<head>
		<title>TED Teaching Load Tracking</title>
		<meta charset = "utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel = "stylesheet" type = "text/css" href = "admin/css/bootstrap.css" />
		<link rel = "stylesheet" type = "text/css" href = "admin/css/jquery.dataTables.css" />
		<link rel = "stylesheet" type = "text/css" href = "admin/css/style.css" />
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
		
	</head>
	
<body>
	<nav class="navbar navbar-default navbar-fixed-top" style="background-color:green;">
		<div class="container-fluid">
			<label class="navbar-brand" id="title">TED Teaching Load Tracking</label>
			
			<ul class = "nav navbar-right">	
				<li class = "dropdown">
					<a class = "user dropdown-toggle" data-toggle = "dropdown" href = "#">
						<span class = "glyphicon glyphicon-user"></span>
						<?php 
						$deptid = '';
						$query = mysqli_query($conn, "SELECT * FROM faculty WHERE IDnum = '$_SESSION[faculty]' ") or die(mysqli_error());				
						while($fetch = mysqli_fetch_array($query)){
							echo $fetch['firstname']." ".$fetch['lastname'];
							$deptid = $fetch['Department'];
							}
						?>
						<b class = "caret"></b>
					</a>
				<ul class = "dropdown-menu">
				<li>
				<a href = "logout.php"><i class = "glyphicon glyphicon-log-out"></i> Logout</a>
					</li>
				</ul>
				</li>
			</ul>	
</div>
	</nav>
	</br> </br> </br> </br>
<div class="panel-body" style="float: right; width: 80%"> 
<h1>PROGRAM CHAIR MENU</h1>


<?php include 'approval_table_progchair.php'?>

<?php include 'progchair_table.php' ?>

<?php include 'progchair_load_updater.php' ?>

<?php include 'printable_form.php'?>




 </div>
<?php include 'sidebar.php'?>
	<div id = "footer">
		<label class = "footer-title">&copy; Copyright TED Teaching Load Tracking <?php echo date("Y", strtotime("+8 HOURS"))?></label>
	</div>
</div>
<?php include 'logoutmodal.php'?>
<?php include 'script.php'?>
<script type="text/javascript">
	$('.btn-delete').on('click', function(){
		var user_id = $(this).attr('id');
		$("#modal_confirm").modal('show');
		$('#btn_yes').attr('name', user_id);
	});
	$('#btn_yes').on('click', function(){
		var id = $(this).attr('name');
		$.ajax({
			type: "POST",
			url: "delete_user.php",
			data:{
				user_id: id
			},
			success: function(){
				$("#modal_confirm").modal('hide');
				$(".del_user" + id).empty();
				$(".del_user" + id).html("<td colspan='6'><center class='text-danger'>Deleting...</center></td>");
				setTimeout(function(){
					$(".del_user" + id).fadeOut('slow');
				}, 1000);
			}
		});
	});
});
</script>
</body>
</html>