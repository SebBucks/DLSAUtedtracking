<table class="center" width="75%"  style="border: 1px solid black; border-collapse: collapse;">
  <tr>
  <?php
  $college = '';
  $department = '';
  $query = mysqli_query($conn, "SELECT * FROM `faculty` WHERE `Idnum` = '$idtrim'") or die(mysqli_error());				
  $fetch = mysqli_fetch_array($query)?>
    <td style="border: 1px solid black; border-collapse: collapse;" align="left">Prepared by: 
    </br>
	<img src="admin/signatures/<?php echo $fetch['Signature']?>" height = "50" width="250">
	</br>
	<?php echo " " . $fetch['firstname']. " " . $fetch['lastname'] ;?> 
	</br> Faculty Member </td><!-- code name-->
	<?php
	 $college = $fetch['College'];
	 $department = $fetch['Department'];

     $query = mysqli_query($conn, "SELECT * FROM `programchair` WHERE `Department` = '$department'") or die(mysqli_error());				
     $fetch = mysqli_fetch_array($query);
	 $progid = $fetch['IDnum'];
	 $query = mysqli_query($conn, "SELECT * FROM `faculty` WHERE `Idnum` = '$progid'") or die(mysqli_error());				
     $fetch = mysqli_fetch_array($query);	 
  ?>
    <td style="border: 1px solid black; border-collapse: collapse;" align="left">Noted by:
    </br>
    	<?php 
	$result = mysqli_query($conn, "SELECT * FROM `approval` WHERE `Idnum` = '$idtrim'") or die(mysqli_error());				
	$row = mysqli_fetch_array($result);
	if($row['progsub'] == 'ok')
	{
	?>
	<img src="admin/signatures/<?php echo $fetch['Signature']?>" height = "50" width="250">
	<?php
	 }
	 ?>
	 </br>
    <?php echo " " . $fetch['firstname']. " " . $fetch['lastname'] ;?> 

	</br> Program Chair </td><!-- code progchair-->
	<?php 
	 $query = mysqli_query($conn, "SELECT * FROM `dean` WHERE `College` = '$college'") or die(mysqli_error());				
     $fetch = mysqli_fetch_array($query);
	 $deanid = $fetch['IDnum'];
	 $query = mysqli_query($conn, "SELECT * FROM `faculty` WHERE `Idnum` = '$deanid'") or die(mysqli_error());				
     $fetch = mysqli_fetch_array($query);
	?>
	
	<td  style="border: 1px solid black; border-collapse: collapse;" align="left">Verified by:  
	</br>
	<?php 
	$result = mysqli_query($conn, "SELECT * FROM `approval` WHERE `Idnum` = '$idtrim'") or die(mysqli_error());				
	$row = mysqli_fetch_array($result);
	if($row['deansub'] == 'ok')
	{
	?>
	 <img src="admin/signatures/<?php echo $fetch['Signature']?>" height = "50" width="250">
	 <?php
	 }
	 ?>
	 </br>
	<?php echo " " . $fetch['firstname']. " " . $fetch['lastname'] ;?>
	
	</br> Dean </td><!-- code dean-->
  </tr>
  <tr>
      <?php 
	 $query = mysqli_query($conn, "SELECT * FROM `management` WHERE `position` = 'Registrar'") or die(mysqli_error());				
     $fetch = mysqli_fetch_array($query);
	 $registrarid = $fetch['IDnum'];
	 $query = mysqli_query($conn, "SELECT * FROM `faculty` WHERE `Idnum` = '$registrarid'") or die(mysqli_error());				
     $fetch = mysqli_fetch_array($query);
	?>
    <td  style="border: 1px solid black; border-collapse: collapse;" align="left">Certified Correct:
    </br>
    <?php 
	$result = mysqli_query($conn, "SELECT * FROM `approval` WHERE `Idnum` = '$idtrim'") or die(mysqli_error());				
	$row = mysqli_fetch_array($result);
	if($row['regsub'] == 'ok')
	{
	?>
	<img src="admin/signatures/<?php echo $fetch['Signature']?>" height = "50" width="250">
	<?php 
	}
	?>
	</br>
    <?php echo " " . $fetch['firstname']. " " . $fetch['lastname'] ;?> 
	
	 </br> Registrar</td><!-- code Registrar-->
	 <?php 
	 $query = mysqli_query($conn, "SELECT * FROM `management` WHERE `position` = 'HR head'") or die(mysqli_error());				
     $fetch = mysqli_fetch_array($query);
	 $hrid = $fetch['IDnum'];
	 $query = mysqli_query($conn, "SELECT * FROM `faculty` WHERE `Idnum` = '$hrid'") or die(mysqli_error());				
     $fetch = mysqli_fetch_array($query);
	?>
    <td  style="border: 1px solid black; border-collapse: collapse;" align="left">Recommending Approval:
    </br>
    <?php 
	$result = mysqli_query($conn, "SELECT * FROM `approval` WHERE `Idnum` = '$idtrim'") or die(mysqli_error());				
	$row = mysqli_fetch_array($result);
	if($row['hrsub'] == 'ok')
	{
	?>
	<img src="admin/signatures/<?php echo $fetch['Signature']?>" height = "50" width="250">
	<?php 
	}
	?>
	</br>
    <?php echo " " . $fetch['firstname']. " " . $fetch['lastname'] ;?> 
	
	 </br> HRDM Director</td><!-- code HR-->
  <?php 
	 $query = mysqli_query($conn, "SELECT * FROM `management` WHERE `position` = 'VCAR'") or die(mysqli_error());				
     $fetch = mysqli_fetch_array($query);
	 $vcarid = $fetch['IDnum'];
	 $query = mysqli_query($conn, "SELECT * FROM `faculty` WHERE `Idnum` = '$vcarid'") or die(mysqli_error());				
     $fetch = mysqli_fetch_array($query);
	?>
    <td  style="border: 1px solid black; border-collapse: collapse;" align="left">Approved:
    </br>
    	<?php 
	$result = mysqli_query($conn, "SELECT * FROM `approval` WHERE `Idnum` = '$idtrim'") or die(mysqli_error());				
	$row = mysqli_fetch_array($result);
	if($row['vcarsub'] == 'ok')
	{
	?>
	<img src="admin/signatures/<?php echo $fetch['Signature']?>" height = "50" width="250">
	<?php 
	}
	?>
	</br>
    <?php echo " " . $fetch['firstname']. " " . $fetch['lastname'] ;?> 

	</br> VCARM</td><!-- code VCAR-->
	 
  </tr>
</table>