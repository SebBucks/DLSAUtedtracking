<?php
$sql = "Select FROM `timetable` WHERE  Idnum ='" . $_GET["id"] . "'";
	

	$idnum = $_GET["id"];
	$first = rtrim($idnum,"'");
	$idtrim = ltrim($first, "'");
	?>

     
	     <?php
		 	$workstatus = '';
			$query = mysqli_query($conn, "SELECT * FROM `faculty` WHERE `Idnum` = '$idtrim'") or die(mysqli_error());				
			while($fetch = mysqli_fetch_array($query)){
			$workstatus = $fetch['WorkStatus'];
			?>
			
	<h3>ID Number: 
       <?php echo $fetch['Idnum']?>
    </h3>
	<h3>Name: 
        <?php echo $fetch['firstname']." ".$fetch['lastname']?>
    </h3>
		
			<?php	
			} 
			?>
	
       <table id= "table" class="table table-bordered">
        <thead>
          <tr> 
            <th>SubjectCode</th>
            <th>Description</th>
			 <th>Section</th>
            <th>StartTime</th>
            <th>EndTime</th>
            <th>Day</th>
            <th>ClassType</th>
          </tr>
        </thead>
        <tbody id = "tablebody">
          <?php 

			$query = mysqli_query($conn, "SELECT * FROM `timetable` WHERE `Idnum` = '$idtrim';") or die(mysqli_error());				
			while($fetch = mysqli_fetch_array($query)){	
						?>
          <tr class="del_user<?php echo $fetch['SubjectCode']?>"> 
            <td><?php echo substr($fetch['SubjectCode'], 0 ,30)."..."?></td>
            <td><?php echo $fetch['Description']?></td>
            <td><?php echo $fetch['Section']?></td>
            <td><?php echo $fetch['StartTime']?></td>
            <td><?php echo $fetch['EndTime']?></td>
            <td><?php echo $fetch['Day']?></td>
            <td><?php echo $fetch['ClassType']?></td>	
          </tr>
		  <?php }?>
        </tbody>
      </table>
	 	 <?php include 'timetable_print.php'?>
         <?php include 'approval_summary.php'?>
		
		
        <div style="clear:both;"></div>
        <div class="modal-footer"> 
          <button class="btn btn-success" data-toggle="modal" data-target="#approve_vcar"><span class="glyphicon glyphicon-save"></span>
		  Approve</button>
		  <button class="btn btn-warning" data-toggle="modal" data-target="#reject_vcar"><span class="glyphicon glyphicon-trash"></span> 
          Reject</button>
		  <button type="button" class="btn btn-danger" onclick="self.close()"><span class="glyphicon glyphicon-remove"></span> 
          Close</button>
        </div>
		
 <br/><br/><br/><br/>
