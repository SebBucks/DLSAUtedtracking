<?php
session_start();
	require_once 'admin/conn.php';

function alert($msg) {
    echo "<script type='text/javascript'>alert('$msg');</script>";
}

if(ISSET($_POST['reject'])){
$load = $_POST['load'];
	if($load == 'COHOC')
	{	
		$note = 'Consultation/Office/Off-Campus Load Problem:';
		$remarks = $_POST['remarks'];
		mysqli_query($conn, "UPDATE approval set submitted = '--', progsub = '--', deansub = '--', regsub = '--', hrsub = '--', vcarsub = '--', reject = '$note"." "."$remarks', progchair = '--' where IDnum = '$_SESSION[idnum]'") or die(mysqli_error());
		alert('Schedule rejected');
		echo"<script>window.location = 'management.php';</script>";
	}
	if($load == 'RL')
	{
		$note = 'Regular Load Problem:';
		$remarks = $_POST['remarks'];
		mysqli_query($conn, "UPDATE approval set submitted = '--', progsub = '--', deansub = '--', regsub = '--', hrsub = '--', vcarsub = '--', reject = '$note"." "."$remarks', progchair = 'ok' where IDnum = '$_SESSION[idnum]'") or die(mysqli_error());
		alert('Schedule rejected');
		echo"<script>window.location = 'management.php';</script>";
	}
	if($load == 'BOTH')
	{
		$note = 'Regular Load Problem and Consultation/Office/Off-Campus Load Problem:';
		$remarks = $_POST['remarks'];
		mysqli_query($conn, "UPDATE approval set submitted = '--', progsub = '--', deansub = '--', regsub = '--', hrsub = '--', vcarsub = '--', reject = '$note"." "."$remarks', progchair = 'ok' where IDnum = '$_SESSION[idnum]'") or die(mysqli_error());
		alert('Schedule rejected');
		echo"<script>window.location = 'management.php';</script>";
	}
}





?>