<div class="modal fade" id="modal_confirm" aria-hidden="true">
		<div class="modal-dialog modal-dialog-centered">
    <div class="modal-content"> 
      <div class="modal-header"> 
        <h3 class="modal-title">System</h3>
      </div>
      <div class="modal-body"> 
        <center>
          <h4 class="text-danger">Are you sure you want to logout?</h4>
        </center>
      </div>
      <div class="modal-footer"> <a type="button" class="btn btn-success" data-dismiss="modal">Cancel</a> 
        <a href="logout.php" class="btn btn-danger">Logout</a> </div>
    </div>
		</div>
	</div>