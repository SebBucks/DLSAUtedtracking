<?php
session_start();
	require_once 'admin/conn.php';

function alert($msg) {
    echo "<script type='text/javascript'>alert('$msg');</script>";
}

if(ISSET($_POST['reject'])){
		$remarks = $_POST['remarks'];
		mysqli_query($conn, "UPDATE approval set submitted = '--', progsub = '--', deansub = '--', regsub = '--', hrsub = '--', vcarsub = '--', reject = '$remarks', progchair = '--' where IDnum = '$_SESSION[idnum]'") or die(mysqli_error());
		alert('Schedule rejected');
		echo"<script>window.location = 'management.php';</script>";
}





?>