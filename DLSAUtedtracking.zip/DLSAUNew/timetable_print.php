<table class="center" width="100%" style="border: 1px solid black; border-collapse: collapse;">
	<tr>
    	<th style="border: 1px solid black; border-collapse: collapse;"> </th>
   	<th style="border: 1px solid black; border-collapse: collapse;">Monday</th>
	<th style="border: 1px solid black; border-collapse: collapse;">Tuesday</th>
	<th style="border: 1px solid black; border-collapse: collapse;">Wednesday</th>
	<th style="border: 1px solid black; border-collapse: collapse;">Thursday</th>
	<th style="border: 1px solid black; border-collapse: collapse;">Friday</th>
	<th style="border: 1px solid black; border-collapse: collapse;">Saturday</th>
 	</tr>
<?php 

$time = array( '07:30','08:50','09:30', '10:10', '11:30','12:50','13:30', '14:10', '15:30', '16:50', '17:30');

 $query=mysqli_query($conn,"select * from timetable where Idnum = '$idtrim'")or die(mysqli_error());
while($fetch = mysqli_fetch_array($query)){
$strstart= strtotime($fetch['StartTime']);
$strend= strtotime($fetch['EndTime']);
array_push($time,date("H:i", $strstart),date("H:i",$strend ));
}
$time = array_unique($time);


$strtime = [];
	foreach($time as $count =>$i){
		$i = strtotime($i);
		$strtime[$count] = $i;
		//echo $strtime[$count] . '<br/>';
		}
		
echo '<br/>';		
sort($strtime);
$strtimecount = count($strtime) ;
	for ($a = 0; $a < $strtimecount-1; $a++){
	
		//echo date('H:i',$a) . '<br/>';
		//$timedisplay = date('H:i',$a);
		$strcountend = $a + 1;
		$cellstart = $strtime[$a];
		$cellend = $strtime[$strcountend];
		
		//echo 'Cellstart '. $a . ' = ' .$cellstart;
		//echo 'Cellend '. $a . ' = ' .$cellend;
		//echo '<br/>';
 
?>
		<tr>
    		<td style="border: 1px solid black; border-collapse: collapse;"><?php echo date('H:i',$strtime[$a]) . '<br/>';?></td>
   			<td style="border: 1px solid black; border-collapse: collapse;"> <?php $cellday = 'M'; ?><?php include 'timetable_print_cell.php'?></td>
			<td style="border: 1px solid black; border-collapse: collapse;"><?php $cellday = 'T';?><?php include 'timetable_print_cell.php'?></td>
			<td style="border: 1px solid black; border-collapse: collapse;"><?php $cellday = 'W';?><?php include 'timetable_print_cell.php'?></td>
			<td style="border: 1px solid black; border-collapse: collapse;"><?php $cellday = 'H';?><?php include 'timetable_print_cell.php'?></td>
			<td style="border: 1px solid black; border-collapse: collapse;"><?php $cellday = 'F';?><?php include 'timetable_print_cell.php'?></td>	
			<td style="border: 1px solid black; border-collapse: collapse;"><?php $cellday = 'S';?><?php include 'timetable_print_cell.php'?></td>
 		</tr>
<?php
	}
?>	
<tr>
    	<td style="border: 1px solid black; border-collapse: collapse;"><?php echo date('H:i',$strtime[$strtimecount-1]);?></td>
    	<td style="border: 1px solid black; border-collapse: collapse;" colspan="6"></td>
</tr>
 		<tr>
 		<td style="border: 1px solid black; border-collapse: collapse;" colspan="7" align="Center" > REMINDERS</td>
 		</td>
 		</tr>
 		<tr>
 		<td style="border: 1px solid black; border-collapse: collapse;" colspan="7" align="Left" > I.	Permanent and probationary full-time faculty must have 24 hours Regular Teaching Load for the 1st term, 20 hours Regular Teaching Load for the 2nd term and 20 hours Regular Teaching Load for the 3rd term.</td>
 		</td>
 		</tr>
 		<tr>
 		<td style="border: 1px solid black; border-collapse: collapse;" colspan="7" align="Left" >II.	Part-time faculty maximum per term Regular Teaching Load is 16 hours.</td>
 		</td>
 		</tr>
 		<tr>
 		<td style="border: 1px solid black; border-collapse: collapse;" colspan="7" align="Left" >III.	Exclusive to permanent and probationary full-time faculty only:
 		</br>
                          Non-Teaching Hours should be labeled as:
        </br>
1.	Off campus (5.5 hours per week)
</br>
2.	Consultation Hours (6 hours per week)
</br>
3.	Office Hours (7.5 hours per week)
</td>
 		</td>
 		</tr>
</table>