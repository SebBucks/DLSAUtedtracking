<?php
	session_start();
	require_once 'admin/conn.php';
	
	
function alert($msg) {
    echo "<script type='text/javascript'>alert('$msg');</script>";
}
//alert($_SESSION['idnum']);
	mysqli_query($conn, "UPDATE `approval` SET progsub='ok' Where IDnum = '$_SESSION[idnum]'") or die(mysqli_error());
	alert('Schedule approved');
	echo"<script>window.location = 'management.php';</script>";
?>
