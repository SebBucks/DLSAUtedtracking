<?php
function fill_progchairComp($conn)  
 {  
    $value = '';  
	$option = ''; 
	$output = ''; 
    $result = mysqli_query($conn, "SELECT * FROM `faculty` WHERE Department = 'Computer Science'") or die(mysqli_error());				
		while($row = mysqli_fetch_array($result)){
       		$value = $row['Idnum'];    
		   	$option = $row['firstname'] . " " .$row['lastname'];   
			$output = "<option value='".$value."'>". $option."</option>";
		}
	return $output;
 } 
?>