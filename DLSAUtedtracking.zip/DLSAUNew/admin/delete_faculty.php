<?php
session_start();
	require_once 'conn.php';
	
	if(ISSET($_POST['delete'])){	
	$idnum = $_POST['deleteid'];	
	$query = mysqli_query($conn, "SELECT * FROM `faculty` WHERE `Idnum` = '$idnum'") or die(mysqli_error());
	$fetch = mysqli_fetch_array($query);
	$filepath = 'signatures/'.$fetch['Signature'];
	//echo $idnum;
	//echo $filepath;
	unlink($filepath);
			mysqli_query($conn, "DELETE FROM `faculty` WHERE `Idnum` = '$idnum'") or die(mysqli_error());
			mysqli_query($conn, "DELETE FROM `timetable` WHERE `Idnum` = '$idnum'") or die(mysqli_error());
			mysqli_query($conn, "DELETE FROM `approval` WHERE `IDnum` = '$idnum'") or die(mysqli_error());
	echo "<script>alert('Faculty Successfully Deleted!')</script>";
	echo "<script>window.location = 'faculty.php'</script>";
}
?>