<?php 
// Include the database config file 
include_once 'conn.php'; 
 
if(!empty($_POST["college_id"])){ 
    // Fetch state data based on the specific country 
    $query = "SELECT * FROM departments WHERE college_id = ".$_POST['college_id']." "; 
    $result = $db->query($query); 
     
    // Generate HTML of state options list 
    if($result->num_rows > 0){ 
        echo '<option value="">Select Department</option>'; 
        while($row = $result->fetch_assoc()){  
            echo '<option value="'.$row['dept_id'].'">'.$row['dept_name'].'</option>'; 
        } 
    }else{ 
        echo '<option value="">Department not available</option>'; 
    } 
	?>