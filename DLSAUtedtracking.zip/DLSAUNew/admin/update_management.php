<?php
	require_once 'conn.php';
//////////////////////////////////////////////////////////////////////////////////////////////////////////
//Update Prog	
	if(ISSET($_POST['updateprog'])){
		$counterconfirm =0;
		$counterformer =0;
		$idnum = trim($_POST['prog']);
		$former = trim($_POST['formerprog']);
		
		//check name
		$query = mysqli_query($conn, "SELECT * FROM `faculty` WHERE IDnum = '$idnum'") or die(mysqli_error());
		$fetch = mysqli_fetch_array($query);
		$name = $fetch['firstname'] . " " . $fetch['lastname'];
			
		//check if it exist in management	
		$query = mysqli_query($conn, "SELECT * FROM `management` ") or die(mysqli_error());
		while($fetch = mysqli_fetch_array($query)){
			$fetchprint = $fetch['IDnum'];
			if($fetchprint == $idnum){
				if($fetch['position'] != 'Dean'){
				$counterconfirm = $counterconfirm + 1;
				}	
			}
		}
		
		//if it does not exist
		if($counterconfirm == 0)
		{
		
		//new edit
		mysqli_query($conn, "UPDATE `faculty` SET management = 'Yes' WHERE IDnum = '$idnum' ") or die(mysqli_error());
		
		mysqli_query($conn, "UPDATE `management` SET IDnum = '$idnum', name = '$name' WHERE position = 'ProgramChair' AND IDnum = '$former' ") or die(mysqli_error());
		
		mysqli_query($conn, "UPDATE `programchair` SET IDnum = '$idnum', ProgramChair = '$name' WHERE IDnum = '$former' ") or die(mysqli_error());
		
		//delete newguy records
		
		mysqli_query($conn, "DELETE FROM timetable WHERE Idnum = '$idnum'") or die(mysqli_error());
		
		mysqli_query($conn, "DELETE FROM approval WHERE Idnum = '$idnum'") or die(mysqli_error());
		
		//former new records	
		$query = mysqli_query($conn, "SELECT * FROM `management`") or die(mysqli_error());
		while($fetch = mysqli_fetch_array($query)){
			$fetchprint = $fetch['IDnum'];
			if($fetchprint == $former){
				$counterformer = $counterformer + 1;	
			}
		}
		if ($counterformer == 0 ){
		mysqli_query($conn, "INSERT INTO `approval` (IDnum, submitted, progsub, deansub, regsub, hrsub, vcarsub, reject, progchair)
							 VALUES ('$former','--','--','--','--','--','--','--','--')") 
							 or die(mysqli_error($conn));
		mysqli_query($conn, "UPDATE `faculty` SET management = 'No' WHERE IDnum = '$former' ") or die(mysqli_error());
		}
							
		echo "<script>alert('Successfully updated!')</script>";
		echo "<script>window.location = 'management_edit.php'</script>";
		//if it exists
		}else{
		echo "<script>alert('ID number already exists in management')</script>";
		echo "<script>window.location = 'management_edit.php'</script>";
		}	
	}
	
	
//////////////////////////////////////////////////////////////////////////////////////////////////////////
//Update Dean
	if(ISSET($_POST['updatedean'])){
		$counterconfirm =0;
		$counterformer =0;
		$idnum = trim($_POST['dean']);
		$former = trim($_POST['formerdean']);
		
		//check name
		$query = mysqli_query($conn, "SELECT * FROM `faculty` WHERE IDnum = '$idnum'") or die(mysqli_error());
		$fetch = mysqli_fetch_array($query);
		$name = $fetch['firstname'] . " " . $fetch['lastname'];
			
		//check if it exist in management	
		$query = mysqli_query($conn, "SELECT * FROM `management` ") or die(mysqli_error());
		while($fetch = mysqli_fetch_array($query)){
			$fetchprint = $fetch['IDnum'];
			if($fetchprint == $idnum){
				if($fetch['position'] != 'ProgramChair'){
				$counterconfirm = $counterconfirm + 1;
				}	
			}
		}
		
		//if it does not exist
		if($counterconfirm == 0)
		{
		
		//new edit
		mysqli_query($conn, "UPDATE `faculty` SET management = 'Yes' WHERE IDnum = '$idnum' ") or die(mysqli_error());
		
		mysqli_query($conn, "UPDATE `management` SET IDnum = '$idnum', name = '$name' WHERE position = 'Dean' AND IDnum = '$former' ") or die(mysqli_error());
		
		mysqli_query($conn, "UPDATE `dean` SET IDnum = '$idnum', Dean = '$name' WHERE IDnum = '$former' ") or die(mysqli_error());
		
		//delete newguy records
		
		mysqli_query($conn, "DELETE FROM timetable WHERE Idnum = '$idnum'") or die(mysqli_error());
		
		mysqli_query($conn, "DELETE FROM approval WHERE Idnum = '$idnum'") or die(mysqli_error());
		
		//former new records	
		$query = mysqli_query($conn, "SELECT * FROM `management`") or die(mysqli_error());
		while($fetch = mysqli_fetch_array($query)){
			$fetchprint = $fetch['IDnum'];
			if($fetchprint == $former){
				$counterformer = $counterformer + 1;	
			}
		}
		if ($counterformer == 0 ){
		mysqli_query($conn, "INSERT INTO `approval` (IDnum, submitted, progsub, deansub, regsub, hrsub, vcarsub, reject, progchair)
							 VALUES ('$former','--','--','--','--','--','--','--','--')") 
							 or die(mysqli_error($conn));
		mysqli_query($conn, "UPDATE `faculty` SET management = 'No' WHERE IDnum = '$former' ") or die(mysqli_error());
		}
							
		echo "<script>alert('Successfully updated!')</script>";
		echo "<script>window.location = 'management_edit.php'</script>";
		//if it exists
		}else{
		echo "<script>alert('ID number already exists in management')</script>";
		echo "<script>window.location = 'management_edit.php'</script>";
		}	
	}

//////////////////////////////////////////////////////////////////////////////////////////////////////////
//Update Registrar
	if(ISSET($_POST['updatereg'])){
		$counterconfirm =0;
		$counterformer =0;
		$idnum = trim($_POST['reg']);
		$former = trim($_POST['formerreg']);
		
		//check name
		$query = mysqli_query($conn, "SELECT * FROM `faculty` WHERE IDnum = '$idnum'") or die(mysqli_error());
		$fetch = mysqli_fetch_array($query);
		$name = $fetch['firstname'] . " " . $fetch['lastname'];
			
		//check if it exist in management	
		$query = mysqli_query($conn, "SELECT * FROM `management` ") or die(mysqli_error());
		while($fetch = mysqli_fetch_array($query)){
			$fetchprint = $fetch['IDnum'];
			if($fetchprint == $idnum){
				$counterconfirm = $counterconfirm + 1;	
			}
		}
		
		//if it does not exist
		if($counterconfirm == 0)
		{
		
		//new edit
		mysqli_query($conn, "UPDATE `faculty` SET management = 'Yes' WHERE IDnum = '$idnum' ") or die(mysqli_error());
		
		mysqli_query($conn, "UPDATE `management` SET IDnum = '$idnum', name = '$name' WHERE position = 'Registrar' AND IDnum = '$former' ") or die(mysqli_error());
		
		
		//delete newguy records
		
		mysqli_query($conn, "DELETE FROM timetable WHERE Idnum = '$idnum'") or die(mysqli_error());
		
		mysqli_query($conn, "DELETE FROM approval WHERE Idnum = '$idnum'") or die(mysqli_error());
		
		//former new records	
		$query = mysqli_query($conn, "SELECT * FROM `management`") or die(mysqli_error());
		while($fetch = mysqli_fetch_array($query)){
			$fetchprint = $fetch['IDnum'];
			if($fetchprint == $former){
				$counterformer = $counterformer + 1;	
			}
		}
		if ($counterformer == 0 ){
		mysqli_query($conn, "INSERT INTO `approval` (IDnum, submitted, progsub, deansub, regsub, hrsub, vcarsub, reject, progchair)
							 VALUES ('$former','--','--','--','--','--','--','--','--')") 
							 or die(mysqli_error($conn));
		mysqli_query($conn, "UPDATE `faculty` SET management = 'No' WHERE IDnum = '$former' ") or die(mysqli_error());
		}
							
		echo "<script>alert('Successfully updated!')</script>";
		echo "<script>window.location = 'management_edit.php'</script>";
		//if it exists
		}else{
		echo "<script>alert('ID number already exists in management')</script>";
		echo "<script>window.location = 'management_edit.php'</script>";
		}	
	}

//////////////////////////////////////////////////////////////////////////////////////////////////////////
//Update HR Head
	if(ISSET($_POST['updatehr'])){
		$counterconfirm =0;
		$counterformer =0;
		$idnum = trim($_POST['hr']);
		$former = trim($_POST['formerhr']);
		
		//check name
		$query = mysqli_query($conn, "SELECT * FROM `faculty` WHERE IDnum = '$idnum'") or die(mysqli_error());
		$fetch = mysqli_fetch_array($query);
		$name = $fetch['firstname'] . " " . $fetch['lastname'];
			
		//check if it exist in management	
		$query = mysqli_query($conn, "SELECT * FROM `management` ") or die(mysqli_error());
		while($fetch = mysqli_fetch_array($query)){
			$fetchprint = $fetch['IDnum'];
			if($fetchprint == $idnum){
				$counterconfirm = $counterconfirm + 1;	
			}
		}
		
		//if it does not exist
		if($counterconfirm == 0)
		{
		
		//new edit
		mysqli_query($conn, "UPDATE `faculty` SET management = 'Yes' WHERE IDnum = '$idnum' ") or die(mysqli_error());
		
		mysqli_query($conn, "UPDATE `management` SET IDnum = '$idnum', name = '$name' WHERE position = 'HR head' AND IDnum = '$former' ") or die(mysqli_error());
		
		
		//delete newguy records
		
		mysqli_query($conn, "DELETE FROM timetable WHERE Idnum = '$idnum'") or die(mysqli_error());
		
		mysqli_query($conn, "DELETE FROM approval WHERE Idnum = '$idnum'") or die(mysqli_error());
		
		//former new records	
		$query = mysqli_query($conn, "SELECT * FROM `management`") or die(mysqli_error());
		while($fetch = mysqli_fetch_array($query)){
			$fetchprint = $fetch['IDnum'];
			if($fetchprint == $former){
				$counterformer = $counterformer + 1;	
			}
		}
		if ($counterformer == 0 ){
		mysqli_query($conn, "INSERT INTO `approval` (IDnum, submitted, progsub, deansub, regsub, hrsub, vcarsub, reject, progchair)
							 VALUES ('$former','--','--','--','--','--','--','--','--')") 
							 or die(mysqli_error($conn));
		mysqli_query($conn, "UPDATE `faculty` SET management = 'No' WHERE IDnum = '$former' ") or die(mysqli_error());
		}
							
		echo "<script>alert('Successfully updated!')</script>";
		echo "<script>window.location = 'management_edit.php'</script>";
		//if it exists
		}else{
		echo "<script>alert('ID number already exists in management')</script>";
		echo "<script>window.location = 'management_edit.php'</script>";
		}	
	}
	
//////////////////////////////////////////////////////////////////////////////////////////////////////////
//Update VCAR
	if(ISSET($_POST['updatevcar'])){
		$counterconfirm =0;
		$counterformer =0;
		$idnum = trim($_POST['vcar']);
		$former = trim($_POST['formervcar']);
		
		//check name
		$query = mysqli_query($conn, "SELECT * FROM `faculty` WHERE IDnum = '$idnum'") or die(mysqli_error());
		$fetch = mysqli_fetch_array($query);
		$name = $fetch['firstname'] . " " . $fetch['lastname'];
			
		//check if it exist in management	
		$query = mysqli_query($conn, "SELECT * FROM `management` ") or die(mysqli_error());
		while($fetch = mysqli_fetch_array($query)){
			$fetchprint = $fetch['IDnum'];
			if($fetchprint == $idnum){
				$counterconfirm = $counterconfirm + 1;	
			}
		}
		
		//if it does not exist
		if($counterconfirm == 0)
		{
		
		//new edit
		mysqli_query($conn, "UPDATE `faculty` SET management = 'Yes' WHERE IDnum = '$idnum' ") or die(mysqli_error());
		
		mysqli_query($conn, "UPDATE `management` SET IDnum = '$idnum', name = '$name' WHERE position = 'VCAR' AND IDnum = '$former' ") or die(mysqli_error());
		
		
		//delete newguy records
		
		mysqli_query($conn, "DELETE FROM timetable WHERE Idnum = '$idnum'") or die(mysqli_error());
		
		mysqli_query($conn, "DELETE FROM approval WHERE Idnum = '$idnum'") or die(mysqli_error());
		
		//former new records	
		$query = mysqli_query($conn, "SELECT * FROM `management`") or die(mysqli_error());
		while($fetch = mysqli_fetch_array($query)){
			$fetchprint = $fetch['IDnum'];
			if($fetchprint == $former){
				$counterformer = $counterformer + 1;	
			}
		}
		if ($counterformer == 0 ){
		mysqli_query($conn, "INSERT INTO `approval` (IDnum, submitted, progsub, deansub, regsub, hrsub, vcarsub, reject, progchair)
							 VALUES ('$former','--','--','--','--','--','--','--','--')") 
							 or die(mysqli_error($conn));
		mysqli_query($conn, "UPDATE `faculty` SET management = 'No' WHERE IDnum = '$former' ") or die(mysqli_error());
		}
							
		echo "<script>alert('Successfully updated!')</script>";
		echo "<script>window.location = 'management_edit.php'</script>";
		//if it exists
		}else{
		echo "<script>alert('ID number already exists in management')</script>";
		echo "<script>window.location = 'management_edit.php'</script>";
		}	
	}
//////////////////////////////////////////////////////////////////////////////////////////////////////////
//Update Chancellor
	if(ISSET($_POST['updatechancellor'])){
		$counterconfirm =0;
		$counterformer =0;
		$idnum = trim($_POST['chancellor']);
		$former = trim($_POST['formerchancellor']);
		
		//check name
		$query = mysqli_query($conn, "SELECT * FROM `faculty` WHERE IDnum = '$idnum'") or die(mysqli_error());
		$fetch = mysqli_fetch_array($query);
		$name = $fetch['firstname'] . " " . $fetch['lastname'];
			
		//check if it exist in management	
		$query = mysqli_query($conn, "SELECT * FROM `management` ") or die(mysqli_error());
		while($fetch = mysqli_fetch_array($query)){
			$fetchprint = $fetch['IDnum'];
			if($fetchprint == $idnum){
				$counterconfirm = $counterconfirm + 1;	
			}
		}
		
		//if it does not exist
		if($counterconfirm == 0)
		{
		
		//new edit
		mysqli_query($conn, "UPDATE `faculty` SET management = 'Yes' WHERE IDnum = '$idnum' ") or die(mysqli_error());
		
		mysqli_query($conn, "UPDATE `management` SET IDnum = '$idnum', name = '$name' WHERE position = 'Chancellor' AND IDnum = '$former' ") or die(mysqli_error());
		
		
		//delete newguy records
		
		mysqli_query($conn, "DELETE FROM timetable WHERE Idnum = '$idnum'") or die(mysqli_error());
		
		mysqli_query($conn, "DELETE FROM approval WHERE Idnum = '$idnum'") or die(mysqli_error());
		
		//former new records	
		$query = mysqli_query($conn, "SELECT * FROM `management`") or die(mysqli_error());
		while($fetch = mysqli_fetch_array($query)){
			$fetchprint = $fetch['IDnum'];
			if($fetchprint == $former){
				$counterformer = $counterformer + 1;	
			}
		}
		if ($counterformer == 0 ){
		mysqli_query($conn, "INSERT INTO `approval` (IDnum, submitted, progsub, deansub, regsub, hrsub, vcarsub, reject, progchair)
							 VALUES ('$former','--','--','--','--','--','--','--','--')") 
							 or die(mysqli_error($conn));
		mysqli_query($conn, "UPDATE `faculty` SET management = 'No' WHERE IDnum = '$former' ") or die(mysqli_error());
		}
							
		echo "<script>alert('Successfully updated!')</script>";
		echo "<script>window.location = 'management_edit.php'</script>";
		//if it exists
		}else{
		echo "<script>alert('ID number already exists in management')</script>";
		echo "<script>window.location = 'management_edit.php'</script>";
		}	
	}
?>