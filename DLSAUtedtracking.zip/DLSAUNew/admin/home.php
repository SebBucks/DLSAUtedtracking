<!DOCTYPE html>
<?php 

	require 'validator.php';
	require_once 'conn.php'
?>
<html lang = "en">
	<head>
		<title>TED Teaching Load Tracking</title>
		<meta charset = "utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel = "stylesheet" type = "text/css" href = "css/bootstrap.css" />
		<link rel = "stylesheet" type = "text/css" href = "css/style.css" />
	</head>
<body>
	<nav class="navbar navbar-default navbar-fixed-top" style="background-color:green;">
		<div class="container-fluid">
			<label class="navbar-brand" id="title">TED Teaching Load Tracking</label>
			<?php 
				$query = mysqli_query($conn, "SELECT * FROM `user` WHERE `user_id` = '$_SESSION[user]'") or die(mysqli_error());
				$fetch = mysqli_fetch_array($query);
			?>
			<ul class = "nav navbar-right">	
				<li class = "dropdown">
					<a class = "user dropdown-toggle" data-toggle = "dropdown" href = "#">
						<span class = "glyphicon glyphicon-user"></span>
						<?php 
							echo $fetch['firstname']." ".$fetch['lastname'];
						?>
						<b class = "caret"></b>
					</a>
				<ul class = "dropdown-menu">
					<li>
						<a href = "logout.php"><i class = "glyphicon glyphicon-log-out"></i> Logout</a>
					</li>
				</ul>
				</li>
			</ul>
		</div>
	</nav>
	<?php include 'sidebar.php'?>
	<div id= "content">
	<br /><br /><br />
	 <form method="POST" action="yearchange.php">
		<div class="alert alert-info"><h3><?php echo 'Change current year';?></h3>
		<br /><br />
		<div class="form-group"> 
		<p>Current Year:</p>
		<?php 
				$query = mysqli_query($conn, "SELECT * FROM `schoolyear` WHERE sy_id= '1'") or die(mysqli_error());
				$fetch = mysqli_fetch_array($query);
			?>
		<p><?php echo $fetch['sycurrent'] ?></p>
		 <p>Change Current Year:</p>
  			<select name="currentyear" id="currentyear">  				 
				<?php 
				$sy = '';
				 for($i=2021; $i<=2099; $i++){
				 	$sy = $i + 1;
				 	echo '<option value="'.$i.' - '.$sy.'">'.$i.' - '.$sy.'</option>';
				 } 
				 ?>
				
			</select>
			</br>
			<button name="yearchange" id="yearchange" class="btn btn-success" ></span> 
          Change Year</button>
          </div>
		</div>
		</form>
	
	<br />
	 <form method="POST" action="termchange.php"  onsubmit="return confirm('CHANGING THE TERM WILL ERASE ALL SUBMITTED SCHEDULES. DO YOU WANT TO CONTINUE?');">
		<div class="alert alert-info"><h3><?php echo 'Change current term';?></h3>
		<br /><br />
		<div class="form-group"> 
		<p>Current Term:</p>
		<?php 
				$query = mysqli_query($conn, "SELECT * FROM `currentsem` WHERE Term_ID= '1'") or die(mysqli_error());
				$fetch = mysqli_fetch_array($query);
			?>
		<p><?php echo $fetch['Term'] ?></p>
		 <p>Change Current Term:</p>
  				<input type="radio" id="1" name="currentterm" value="1">
 					 <label for="1">1</label><br>
  				<input type="radio" id="2" name="currentterm" value="2" >
  					<label for="2">2</label><br>
  				<input type="radio" id="3" name="currentterm" value="3">
 					 <label for="3">3</label>
			</br>
			<button name="termchange" id="termchange" class="btn btn-success"></span> 
          Change Term</button>
          </div>
		</div>
		</form>
	<br />
	 <form method="POST" action="effdatechange.php">
		<div class="alert alert-info"><h3><?php echo 'Change current effectivity date';?></h3>
		<br /><br />
		<div class="form-group"> 
		<p>Current Effectivity date:</p>
		<?php 
				$query = mysqli_query($conn, "SELECT * FROM `effectivitydate` WHERE effdate_id = '1'") or die(mysqli_error());
				$fetch = mysqli_fetch_array($query);
			?>
		<p><?php echo $fetch['effdate'] ?></p>
		 <p>Change Current Effectivity Date:</p>
  			<input type ="date" id="currenteffdate" name = "currenteffdate">
			</br>
			<button name="effdatechange" id="effdatechange" class="btn btn-success" ></span> 
          Change Effectivity Date</button>
          </div>
		</div>
		</form>
	</div>			
	<div id = "footer">
		<label class = "footer-title">&copy; Copyright TED Teaching Load Tracking <?php echo date("Y", strtotime("+8 HOURS"))?></label>
	</div>
<?php include 'script.php'?>	
</body>
</html>