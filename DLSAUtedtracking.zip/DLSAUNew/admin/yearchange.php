<?php
session_start();
	require_once 'conn.php';

function alert($msg) {
    echo "<script type='text/javascript'>alert('$msg');</script>";
}
	
	if(ISSET($_POST['yearchange'])){
		$yearchange = $_POST['currentyear'];
		mysqli_query($conn, "UPDATE `schoolyear` SET sycurrent = '$yearchange' where sy_id = '1'") or die(mysqli_error());
	}
	echo "<script>window.location = 'home.php'</script>";
	?>
	