<?php
	require_once 'conn.php';
	
	if(ISSET($_POST['update'])){
		$idnum = $_POST['idnum'];
		$firstname = $_POST['firstname'];
		$lastname = $_POST['lastname'];
		$status = $_POST['status'];
		$workstatus = $_POST['workstatus'];
		$password = ($_POST['password']);
		$coldept = $_POST['coldept'];
		$parts = explode('--', $coldept);
		$college = trim($parts[0]);
		$department = trim($parts[1]);
		$rowid =  $_POST['rowid'];
		$rowprint = '';

		
			$query = mysqli_query($conn, "SELECT * FROM `faculty`") or die(mysqli_error());
			while($fetch = mysqli_fetch_array($query)){
				$fetchprint = $fetch['Idnum'];
				if($fetchprint == $idnum){
					$rowprint = $fetch['row_id'];	
				}
			}

			if($rowid == $rowprint){
				mysqli_query($conn, "UPDATE `faculty` SET IDnum = '$idnum', firstname = '$firstname',
									lastname = '$lastname', status = '$status', College = '$college', 
									Department = '$department', WorkStatus = '$workstatus', 
									passcode = '$password' WHERE row_id = '$rowid'") or die(mysqli_error());
									
				echo "<script>alert('Successfully updated!')</script>";
				echo "<script>window.location = 'faculty.php'</script>";
				}else{
				echo "<script>alert('ID number already exists')</script>";
				echo "<script>window.location = 'faculty.php'</script>";
				}
	
	}
?>