<?php
	session_start();
	
//f(!ISSET($_SESSION['faculty'])){
//header("location: index.php");
	
?>