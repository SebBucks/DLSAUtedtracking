<?php
session_start();
	require_once 'conn.php';

function alert($msg) {
    echo "<script type='text/javascript'>alert('$msg');</script>";
}
	
	if(ISSET($_POST['effdatechange'])){
		$year = explode("-",$_POST['currenteffdate'])[0];
		$month = explode("-",$_POST['currenteffdate'])[1];
		$day = explode("-",$_POST['currenteffdate'])[2];
		if($month =="01"){
		$month = "January";
		}elseif($month =="02"){
		$month = "February";
		}elseif($month =="03"){
		$month = "March";
		}elseif($month =="04"){
		$month = "April";
		}elseif($month =="05"){
		$month = "May";
		}elseif($month =="06"){
		$month = "June";
		}elseif($month =="07"){
		$month = "July";
		}elseif($month =="08"){
		$month = "August";
		}elseif($month =="09"){
		$month = "September";
		}elseif($month =="10"){
		$month = "October";
		}elseif($month =="11"){
		$month = "November";
		}elseif($month =="12"){
		$month = "December";
		}
		$finaldate = $month." " . $day . ", ".$year;
		mysqli_query($conn, "UPDATE `effectivitydate` SET effdate = '$finaldate' where effdate_id = '1'") or die(mysqli_error());
	}
	echo "<script>window.location = 'home.php'</script>";
	?>
	