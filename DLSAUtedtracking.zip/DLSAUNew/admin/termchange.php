<?php
session_start();
	require_once 'conn.php';

function alert($msg) {
    echo "<script type='text/javascript'>alert('$msg');</script>";
}
	
	if(ISSET($_POST['termchange'])){
		$termchange = $_POST['currentterm'];
		mysqli_query($conn, "UPDATE `currentsem` SET term = '$termchange' where Term_ID = '1'") or die(mysqli_error());
		mysqli_query($conn, "DELETE FROM timetable") or die(mysqli_error());
	}
	echo "<script>window.location = 'home.php'</script>";
	?>
	