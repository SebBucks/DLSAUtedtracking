<?php
	require_once 'conn.php';
	
	if(ISSET($_POST['add'])){
	//file upload
	$fileNameNew = '';
	$file = $_FILES['file'];
	
	$fileName =  $_FILES['file']['name'];
	$fileTmpName =  $_FILES['file']['tmp_name'];
	$fileSize =  $_FILES['file']['size'];
	$fileError =  $_FILES['file']['error'];
	$fileType =  $_FILES['file']['type'];
	
	$fileExt = explode('.',$fileName);
	$fileActualName = str_replace(' ','',$fileExt[0]);
	$fileActualExt = strtolower(end($fileExt));
	$allowed = array('jpg', 'jpeg', 'png', 'pdf');
	
	$destination_path = getcwd().'/signatures/';
	$fileNameNew = $fileActualName.".". $fileActualExt;
	
	while(file_exists($destination_path.$fileNameNew))
	{
	$fileNameNew = $fileActualName. rand().".". $fileActualExt;
	}
	
	
	//others
		$counterconfirm = 0;
		$idnum = trim($_POST['idnum']);
		$firstname = $_POST['firstname'];
		$lastname = $_POST['lastname'];
		$status = $_POST['status'];
		$workstatus = $_POST['workstatus'];
		$password = ($_POST['password']);
		$coldept = $_POST['coldept'];
		$parts = explode('--', $coldept);
		$college = trim($parts[0]);
		$department = trim($parts[1]);
		$query = mysqli_query($conn, "SELECT * FROM `faculty`") or die(mysqli_error());
		while($fetch = mysqli_fetch_array($query)){
			$fetchprint = $fetch['Idnum'];
			if($fetchprint == $idnum){
				$counterconfirm = $counterconfirm + 1;	
			}
		}
		
	if(in_array($fileActualExt, $allowed)){
		if($fileError === 0){
			if($counterconfirm == 0)
				{
					mysqli_query($conn, "INSERT INTO `faculty` (IDnum, firstname, lastname, status, management, College, Department, WorkStatus, passcode, Signature)
							 VALUES ('$idnum','$firstname','$lastname','$status','No','$college','$department','$workstatus','$password','$fileNameNew')") 
							 or die(mysqli_error());
						 
					mysqli_query($conn, "INSERT INTO `approval` (IDnum, submitted, progsub, deansub, regsub, hrsub, vcarsub, reject, progchair)
							 VALUES ('$idnum','--','--','--','--','--','--','--','--')") 
							 or die(mysqli_error($conn));
							 
					
					$fileDestination = $destination_path.$fileNameNew;
					move_uploaded_file($fileTmpName, $fileDestination);					 			
					echo "<script>alert('Successfully Added!')</script>";
					echo "<script>window.location = 'faculty.php'</script>";
					}
					else{
					
					echo "<script>alert('ID number already exists')</script>";
					echo "<script>window.location = 'faculty.php'</script>";
					}	
				
		}else{
			echo "<script>alert('There was an error uploading your file!')</script>";
			echo "<script>window.location = 'faculty.php'</script>";
		}
	}else{
		echo "<script>alert('You cannot upload files of this type!')</script>";
		echo "<script>window.location = 'faculty.php'</script>";
	}
		
	
	}
?>