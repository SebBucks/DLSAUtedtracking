<div id="sidebar">
	<ul id = "menu" class = "nav menu">
		<li><a href = "home.php"><i class = "glyphicon glyphicon-home"></i> Dashboard</a></li>
		<li><a href = ""><i class = "glyphicon glyphicon-user"></i> Accounts</a>
			<ul>
				<li><a href = "user.php"><i class = "glyphicon glyphicon-user"></i> Users</a></li>
				<li><a href = "faculty.php"><i class = "glyphicon glyphicon-user"></i> Faculty</a></li>
				<li><a href = "management_edit.php"><i class = "glyphicon glyphicon-user"></i> Management</a></li>
			</ul>
		</li>
	</ul>
</div>