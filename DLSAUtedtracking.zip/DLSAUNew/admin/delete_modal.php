<div class="modal fade" id="delete_modal<?php echo $fetch['Idnum']?>" aria-hidden="true">
		<div class="modal-dialog modal-dialog-centered">
			
    <div class="modal-content"> 
	<form method="POST" action="delete_faculty.php" >
      <div class="modal-header"> 
        <h3 class="modal-title">System</h3>
      </div>
      <div class="modal-body"> 
	  <input type="hidden" name="deleteid" value="<?php echo $fetch['Idnum']?>">
        <center>
          <h3 class="text-danger">All files of the Faculty will be deleted too</h3>		 
        </center>
        <center>
          <h3 class="text-danger">Are you sure you want to delete this data?</h3>
        </center>
      </div>
      <div class="modal-footer"> 
        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
        <button name="delete" id="delete" class="btn btn-success" ><span class="glyphicon glyphicon-trash"></span> 
          Yes</button>
    </div>
	</form>
		</div>
	</div></div>