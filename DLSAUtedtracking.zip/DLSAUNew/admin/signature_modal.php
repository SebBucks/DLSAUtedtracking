<div class="modal fade" id="signature_modal<?php echo $fetch['Idnum']?>" aria-hidden="true">
		<div class="modal-dialog modal-dialog-centered">
			
    <div class="modal-content"> 
	<form method="POST" action="signature_edit.php"  enctype="multipart/form-data">
      <div class="modal-header"> 
        <h3 class="modal-title">System</h3>
      </div>
      <div class="modal-body"> 
	  <img src="signatures/<?php echo $fetch['Signature']?>" height = "100" width="300">
	  <div class="form-group"> 
              <label>Signature</label>
              <input type="file" name="file">
            </div>
	  <input type="hidden" name="editsign" value="<?php echo $fetch['Idnum']?>">       
      </div>
      <div class="modal-footer"> 
        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
        <button name="edit" id="edit" class="btn btn-warning" ><span class="glyphicon glyphicon-edit"></span> 
          Update</button>
    </div>
	</form>
		</div>
	</div></div>