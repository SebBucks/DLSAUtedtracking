<?php
session_start();
	require_once 'conn.php';
	
	if(ISSET($_POST['edit'])){
	$fileNameNew = '';
	$file = $_FILES['file'];
	
	$fileName =  $_FILES['file']['name'];
	$fileTmpName =  $_FILES['file']['tmp_name'];
	$fileSize =  $_FILES['file']['size'];
	$fileError =  $_FILES['file']['error'];
	$fileType =  $_FILES['file']['type'];
	
	$fileExt = explode('.',$fileName);
	$fileActualName = str_replace(' ','',$fileExt[0]);
	$fileActualExt = strtolower(end($fileExt));
	$allowed = array('jpg', 'jpeg', 'png', 'pdf');
	
	$destination_path = getcwd().'/signatures/';
	$fileNameNew = $fileActualName.".". $fileActualExt;
	
	while(file_exists($destination_path.$fileNameNew))
	{
	$fileNameNew = $fileActualName. rand().".". $fileActualExt;
	}
	
	$idnum = $_POST['editsign'];
	$query = mysqli_query($conn, "SELECT * FROM `faculty` WHERE `Idnum` = '$idnum'") or die(mysqli_error());
	$fetch = mysqli_fetch_array($query);
	$filepath = 'signatures/'.$fetch['Signature'];
	
	
	
	if(in_array($fileActualExt, $allowed)){
		if($fileError === 0){
					unlink($filepath);
					$fileDestination = $destination_path.$fileNameNew;
					move_uploaded_file($fileTmpName, $fileDestination);
					mysqli_query($conn, "UPDATE `faculty` SET `Signature` = '$fileNameNew' WHERE `Idnum` = '$idnum'") or die(mysqli_error($conn));					 			
					echo "<script>alert('Signature Successfully Changed!')</script>";
					echo "<script>window.location = 'faculty.php'</script>";
			}else{
			echo "<script>alert('There was an error uploading your file!')</script>";
			echo "<script>window.location = 'faculty.php'</script>";
		}
	}else{
		echo "<script>alert('You cannot upload files of this type!')</script>";
		echo "<script>window.location = 'faculty.php'</script>";
	}
		
}
	





?>