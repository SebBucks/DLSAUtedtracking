<!DOCTYPE html>
<?php 
	require 'validator.php';
	require_once 'conn.php'
?>
<html lang = "en">
	<head>
		<title>TED Teaching Load Tracking</title>
		<meta charset = "utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel = "stylesheet" type = "text/css" href = "css/bootstrap.css" />
		<link rel = "stylesheet" type = "text/css" href = "css/jquery.dataTables.css" />
		<link rel = "stylesheet" type = "text/css" href = "css/style.css" />
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
	</head>
<body>
<nav class="navbar navbar-default navbar-fixed-top" style="background-color:green;">
		<div class="container-fluid">
			<label class="navbar-brand" id="title">TED Teaching Load Tracking</label>
			<?php 
				$query = mysqli_query($conn, "SELECT * FROM `user` WHERE `user_id` = '$_SESSION[user]'") or die(mysqli_error());
				$fetch = mysqli_fetch_array($query);
			?>
			<ul class = "nav navbar-right">	
				<li class = "dropdown">
					<a class = "user dropdown-toggle" data-toggle = "dropdown" href = "#">
						<span class = "glyphicon glyphicon-user"></span>
						<?php 
							echo $fetch['firstname']." ".$fetch['lastname'];
						?>
						<b class = "caret"></b>
					</a>
				<ul class = "dropdown-menu">
					<li>
						<a href = "logout.php"><i class = "glyphicon glyphicon-log-out"></i> Logout</a>
					</li>
				</ul>
				</li>
			</ul>
		</div>
	</nav>


<?php include 'sidebar.php'?>
<div id = "content">

		<br /><br /><br />
<h3>Program Chair</h3>
<table id = "table" class="table table-bordered">
			<thead>
				<tr>
					<th>Name</th>
					<th>Department</th>
					<th>Change</th>
				</tr>
			</thead>
		<tbody>
		<?php
		$query = mysqli_query($conn, "SELECT * FROM `programchair`") or die(mysqli_error());				
		while($fetch = mysqli_fetch_array($query)){
		$name =$fetch['ProgramChair'];
		$dept =$fetch['Department'];
		?>
		<tr class="del_user<?php echo $fetch['IDnum']?>">
			<td><?php echo $name?></td>
			<td><?php echo $dept?></td>
			<td><center><button class="btn btn-warning" data-toggle="modal" data-target="#edit_progchair<?php echo $fetch['IDnum']?>">
			<span class="glyphicon glyphicon-edit"></span>Change</button></center></td>
		</tr>	

	<div class="modal fade" id="edit_progchair<?php echo $fetch['IDnum']?>" aria-hidden="true">
		<div class="modal-dialog modal-dialog-centered">
        <div class="modal-content"> 
          <form method="POST" action="update_management.php">
            <div class="modal-header"> 
              <h4 class="modal-title">Update Program Chair</h4>
            </div>
            <div class="modal-body"> 
              <div class="col-md-15"> 
                <div class="form-group"> 
                  <label>Faculty </label>
                  <select id ='prog' name="prog" class="form-control" required="required">
                    <?php
						$department = $fetch['Department'];	
					 	$value = '';  
						$option = ''; 
						$output = ''; 
						$result = mysqli_query($conn, "SELECT * FROM `faculty` WHERE `Department` = '$department'") or die(mysqli_error());				
							while($row = mysqli_fetch_array($result)){
								$value = $row['Idnum'];    
								$option = $row['firstname'] . " " .  $row['lastname'];   
								$output = "<option value='".$value."'>". $option."</option>";
								echo $output;
							}
					?>
                  </select>
                  <input type="hidden" id="formerprog" name="formerprog" value="<?php echo $fetch['IDnum']?>">
                </div>
              </div>
            </div>
            <div class="modal-footer"> 
              <button type="button" class="btn btn-danger" data-dismiss="modal"><span class="glyphicon glyphicon-remove"></span> 
              Close</button>
              <button name="updateprog" id="updateprog" class="btn btn-warning" onclick="return confirm('Are you sure? This will delete the faculty records');" ><span class="glyphicon glyphicon-save"></span> 
              Update</button>
            </div>
          </form>
        </div>
		</div>
	</div>
<?php } ?>
		
		</tbody>
</table>


<!------------------------------------------------------------------------------------------------------------------------------------------------------->
<br />		

<h3>Dean</h3>
<table id = "table2" class="table table-bordered">
			<thead>
				<tr>
					<th>Name</th>
					<th>College</th>
					<th>Change</th>
				</tr>
			</thead>
		<tbody>
		<?php
		$query = mysqli_query($conn, "SELECT * FROM `dean`") or die(mysqli_error());				
		while($fetch = mysqli_fetch_array($query)){
		$name =$fetch['Dean'];
		$dept =$fetch['College'];
		?>
		<tr class="del_user<?php echo $fetch['IDnum']?>">
			<td><?php echo $name?></td>
			<td><?php echo $dept?></td>
			<td><center><button class="btn btn-warning" data-toggle="modal" data-target="#edit_dean<?php echo $fetch['IDnum']?>">
			<span class="glyphicon glyphicon-edit"></span>Change</button></center></td>
		</tr>	

	<div class="modal fade" id="edit_dean<?php echo $fetch['IDnum']?>" aria-hidden="true">
		<div class="modal-dialog modal-dialog-centered">
        <div class="modal-content"> 
          <form method="POST" action="update_management.php">
            <div class="modal-header"> 
              <h4 class="modal-title">Update Dean</h4>
            </div>
            <div class="modal-body"> 
              <div class="col-md-15"> 
                <div class="form-group"> 
                  <label>Faculty </label>
                  <select id ='dean' name="dean" class="form-control" required="required">
                    <?php
						$college = $fetch['College'];	
					 	$value = '';  
						$option = ''; 
						$output = ''; 
						$result = mysqli_query($conn, "SELECT * FROM `faculty` WHERE `College` = '$college'") or die(mysqli_error());				
							while($row = mysqli_fetch_array($result)){
								$value = $row['Idnum'];    
								$option = $row['firstname'] . " " .  $row['lastname'];   
								$output = "<option value='".$value."'>". $option."</option>";
								echo $output;
							}
					?>
                  </select>
                  <input type="hidden" id="formerdean" name="formerdean" value="<?php echo $fetch['IDnum']?>">
                </div>
              </div>
            </div>
            <div class="modal-footer"> 
              <button type="button" class="btn btn-danger" data-dismiss="modal"><span class="glyphicon glyphicon-remove"></span> 
              Close</button>
              <button name="updatedean" id="updatedean" class="btn btn-warning" onclick="return confirm('Are you sure? This will delete the faculty records');"><span class="glyphicon glyphicon-save"></span> 
              Update</button>
            </div>
          </form>
        </div>
		</div>
	</div>
 <?php } ?>	
		</tbody>
</table> 




<!------------------------------------------------------------------------------------------------------------------------------------------------------->
	<br />	

<h3>Registrar</h3>
<table  class="table table-bordered">
			<thead>
				<tr>
					<th>Name</th>
					<th>Change</th>
				</tr>
			</thead>
		<tbody>
		<?php
		$query = mysqli_query($conn, "SELECT * FROM `management` Where position ='Registrar'") or die(mysqli_error());				
		while($fetch = mysqli_fetch_array($query)){
		$name =$fetch['name'];
		?>
		<tr class="del_user<?php echo $fetch['IDnum']?>">
					<td><?php echo $name?></td>
					<td><center><button class="btn btn-warning" data-toggle="modal" data-target="#edit_reg<?php echo $fetch['IDnum']?>">
			<span class="glyphicon glyphicon-edit"></span>Change</button></center></td>
				</tr>
				<div class="modal fade" id="edit_reg<?php echo $fetch['IDnum']?>" aria-hidden="true">
		<div class="modal-dialog modal-dialog-centered">
        <div class="modal-content"> 
          <form method="POST" action="update_management.php">
            <div class="modal-header"> 
              <h4 class="modal-title">Update Registrar</h4>
            </div>
            <div class="modal-body"> 
              <div class="col-md-15"> 
                <div class="form-group"> 
                  <label>Faculty </label>
                  <select id ='reg' name="reg" class="form-control" required="required">
                    <?php	
					 	$value = '';  
						$option = ''; 
						$output = ''; 
						$result = mysqli_query($conn, "SELECT * FROM `faculty`") or die(mysqli_error());				
							while($row = mysqli_fetch_array($result)){
								$value = $row['Idnum'];    
								$option = $row['firstname'] . " " .  $row['lastname'];   
								$output = "<option value='".$value."'>". $option."</option>";
								echo $output;
							}
					?>
                  </select>
                  <input type="hidden" id="formerreg" name="formerreg" value="<?php echo $fetch['IDnum']?>">
                </div>
              </div>
            </div>
            <div class="modal-footer"> 
              <button type="button" class="btn btn-danger" data-dismiss="modal"><span class="glyphicon glyphicon-remove"></span> 
              Close</button>
              <button name="updatereg" id="updatereg" class="btn btn-warning" onclick="return confirm('Are you sure? This will delete the faculty records');" ><span class="glyphicon glyphicon-save"></span> 
              Update</button>
            </div>
          </form>
        </div>
		</div>
	</div>
		<?php 
		}
		?>
		</tbody>
</table>
<!------------------------------------------------------------------------------------------------------------------------------------------------------->
	<br />

<h3>HR Head</h3>
<table class="table table-bordered">
			<thead>
				<tr>
					<th>Name</th>
					<th>Change</th>
				</tr>
			</thead>
		<tbody>
		<?php
		$query = mysqli_query($conn, "SELECT * FROM `management` Where position ='HR Head'") or die(mysqli_error());				
		while($fetch = mysqli_fetch_array($query)){
		$name =$fetch['name'];
		?>
		<tr class="del_user<?php echo $fetch['IDnum']?>">
					<td><?php echo $name?></td>
					<td><center><button class="btn btn-warning" data-toggle="modal" data-target="#edit_hr<?php echo $fetch['IDnum']?>">
			<span class="glyphicon glyphicon-edit"></span>Change</button></center></td>
				</tr>
				
		<div class="modal fade" id="edit_hr<?php echo $fetch['IDnum']?>" aria-hidden="true">
		<div class="modal-dialog modal-dialog-centered">
        <div class="modal-content"> 
          <form method="POST" action="update_management.php">
            <div class="modal-header"> 
              <h4 class="modal-title">Update HR head</h4>
            </div>
            <div class="modal-body"> 
              <div class="col-md-15"> 
                <div class="form-group"> 
                  <label>Faculty </label>
                  <select id ='hr' name="hr" class="form-control" required="required">
                    <?php	
					 	$value = '';  
						$option = ''; 
						$output = ''; 
						$result = mysqli_query($conn, "SELECT * FROM `faculty`") or die(mysqli_error());				
							while($row = mysqli_fetch_array($result)){
								$value = $row['Idnum'];    
								$option = $row['firstname'] . " " .  $row['lastname'];   
								$output = "<option value='".$value."'>". $option."</option>";
								echo $output;
							}
					?>
                  </select>
                  <input type="hidden" id="formerhr" name="formerhr" value="<?php echo $fetch['IDnum']?>">
                </div>
              </div>
            </div>
            <div class="modal-footer"> 
              <button type="button" class="btn btn-danger" data-dismiss="modal"><span class="glyphicon glyphicon-remove"></span> 
              Close</button>
              <button name="updatehr" id="updatehr" class="btn btn-warning" onclick="return confirm('Are you sure? This will delete the faculty records');" ><span class="glyphicon glyphicon-save"></span> 
              Update</button>
            </div>
          </form>
        </div>
		</div>
	</div>
		<?php 
		}
		?>
		</tbody>
</table>

<!------------------------------------------------------------------------------------------------------------------------------------------------------->
	<br />
<h3>VCAR</h3>
<table class="table table-bordered">
			<thead>
				<tr>
					<th>Name</th>
					<th>Change</th>
				</tr>
			</thead>
		<tbody>
		<?php
		$query = mysqli_query($conn, "SELECT * FROM `management` Where position ='VCAR'") or die(mysqli_error());				
		while($fetch = mysqli_fetch_array($query)){
		$name =$fetch['name'];
		?>
		<tr class="del_user<?php echo $fetch['IDnum']?>">
					<td><?php echo $name?></td>
					<td><center><button class="btn btn-warning" data-toggle="modal" data-target="#edit_vcar<?php echo $fetch['IDnum']?>">
			<span class="glyphicon glyphicon-edit"></span>Change</button></center></td>
				</tr>
		
		<div class="modal fade" id="edit_vcar<?php echo $fetch['IDnum']?>" aria-hidden="true">
		<div class="modal-dialog modal-dialog-centered">
        <div class="modal-content"> 
          <form method="POST" action="update_management.php">
            <div class="modal-header"> 
              <h4 class="modal-title">Update VCAR</h4>
            </div>
            <div class="modal-body"> 
              <div class="col-md-15"> 
                <div class="form-group"> 
                  <label>Faculty </label>
                  <select id ='vcar' name="vcar" class="form-control" required="required">
                    <?php	
					 	$value = '';  
						$option = ''; 
						$output = ''; 
						$result = mysqli_query($conn, "SELECT * FROM `faculty`") or die(mysqli_error());				
							while($row = mysqli_fetch_array($result)){
								$value = $row['Idnum'];    
								$option = $row['firstname'] . " " .  $row['lastname'];   
								$output = "<option value='".$value."'>". $option."</option>";
								echo $output;
							}
					?>
                  </select>
                  <input type="hidden" id="formervcar" name="formervcar" value="<?php echo $fetch['IDnum']?>">
                </div>
              </div>
            </div>
            <div class="modal-footer"> 
              <button type="button" class="btn btn-danger" data-dismiss="modal"><span class="glyphicon glyphicon-remove"></span> 
              Close</button>
              <button name="updatevcar" id="updatevcar" class="btn btn-warning" onclick="return confirm('Are you sure? This will delete the faculty records');"><span class="glyphicon glyphicon-save"></span> 
              Update</button>
            </div>
          </form>
        </div>
		</div>
	</div>
		<?php 
		}
		?>
		</tbody>
</table>

<!------------------------------------------------------------------------------------------------------------------------------------------------------->
	<br />
<h3>Chancellor</h3>
<table  class="table table-bordered">
			<thead>
				<tr>
					<th>Name</th>
					<th>Change</th>
				</tr>
			</thead>
		<tbody>
		<?php
		$query = mysqli_query($conn, "SELECT * FROM `management` Where position ='Chancellor'") or die(mysqli_error());				
		while($fetch = mysqli_fetch_array($query)){
		$name =$fetch['name'];
		?>
		<tr class="del_user<?php echo $fetch['IDnum']?>">
					<td><?php echo $name?></td>
					<td><center><button class="btn btn-warning" data-toggle="modal" data-target="#edit_vcar<?php echo $fetch['IDnum']?>">
			<span class="glyphicon glyphicon-edit"></span>Change</button></center></td>
				</tr>
		
		<div class="modal fade" id="edit_vcar<?php echo $fetch['IDnum']?>" aria-hidden="true">
		<div class="modal-dialog modal-dialog-centered">
        <div class="modal-content"> 
          <form method="POST" action="update_management.php">
            <div class="modal-header"> 
              <h4 class="modal-title">Update Chancellor</h4>
            </div>
            <div class="modal-body"> 
              <div class="col-md-15"> 
                <div class="form-group"> 
                  <label>Faculty </label>
                  <select id ='chancellor' name="chancellor" class="form-control" required="required">
                    <?php	
					 	$value = '';  
						$option = ''; 
						$output = ''; 
						$result = mysqli_query($conn, "SELECT * FROM `faculty`") or die(mysqli_error());				
							while($row = mysqli_fetch_array($result)){
								$value = $row['Idnum'];    
								$option = $row['firstname'] . " " .  $row['lastname'];   
								$output = "<option value='".$value."'>". $option."</option>";
								echo $output;
							}
					?>
                  </select>
                  <input type="hidden" id="formerchancellor" name="formerchancellor" value="<?php echo $fetch['IDnum']?>">
                </div>
              </div>
            </div>
            <div class="modal-footer"> 
              <button type="button" class="btn btn-danger" data-dismiss="modal"><span class="glyphicon glyphicon-remove"></span> 
              Close</button>
              <button name="updatechancellor" id="updatechancellor" class="btn btn-warning" onclick="return confirm('Are you sure? This will delete the faculty records');"><span class="glyphicon glyphicon-save"></span> 
              Update</button>
            </div>
          </form>
        </div>
		</div>
	</div>
		<?php 
		}
		?>
		</tbody>
</table>
<br /><br /><br />	
</div>

		
<div id = "footer">
		<label class = "footer-title">&copy; Copyright TED Teaching Load Tracking <?php echo date("Y", strtotime("+8 HOURS"))?></label>
	</div>
<?php include 'script.php'?>
<script type="text/javascript">
$(document).ready(function(){
	$('.btn-delete').on('click', function(){
		var Idnum = $(this).attr('id');
		$("#modal_confirm").modal('show');
		$('#btn_yes').attr('name', Idnum);
	});
	
	$('#btn_yes').on('click', function(){
		var id = $(this).attr('name');
		$.ajax({
			type: "POST",
			url: "delete_faculty.php",
			data:{Idnum: id},
			success: function(){
				$("#modal_confirm").modal('hide');
				$(".del_faculty" + id).empty();
				$(".del_faculty" + id).html("<td colspan='6'><center class='text-danger'>Deleting...</center></td>");
				setTimeout(function(){
					$(".del_faculty" + id).fadeOut('slow');
				}, 1000);
			}
		});
	});		
});
</script>	
</body>
</html>
