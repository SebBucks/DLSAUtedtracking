-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 13, 2021 at 01:02 PM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.2.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `tedtracking`
--

-- --------------------------------------------------------

--
-- Table structure for table `approval`
--

CREATE TABLE `approval` (
  `IDnum` varchar(20) NOT NULL,
  `submitted` text NOT NULL,
  `progsub` text NOT NULL,
  `deansub` text NOT NULL,
  `regsub` text NOT NULL,
  `hrsub` text NOT NULL,
  `vcarsub` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `approval`
--

INSERT INTO `approval` (`IDnum`, `submitted`, `progsub`, `deansub`, `regsub`, `hrsub`, `vcarsub`) VALUES
('07-179-01', 'ok', '--', '--', '--', '--', '--');

-- --------------------------------------------------------

--
-- Table structure for table `codesubj`
--

CREATE TABLE `codesubj` (
  `SubjectCode` varchar(20) NOT NULL,
  `Description` text NOT NULL,
  `Units` int(11) NOT NULL,
  `ClassType` varchar(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `codesubj`
--

INSERT INTO `codesubj` (`SubjectCode`, `Description`, `Units`, `ClassType`) VALUES
('ITC101', 'Intro to Computing', 3, 'R'),
('ITS201', 'Intro to Statistics', 3, 'R'),
('PROG101A', 'Programming 101 Lec', 3, 'R'),
('ETS101', 'Emerging Technologies in Society', 3, 'R'),
('PROG101B', 'Programming 101 Lab', 1, 'R'),
('CE101', 'Computer Lab Etiquette', 1, 'R'),
('AJP201B', 'Advanced Java Programming Lab', 1, 'R');

-- --------------------------------------------------------

--
-- Table structure for table `coldept`
--

CREATE TABLE `coldept` (
  `id_no` int(11) NOT NULL,
  `college` text NOT NULL,
  `department` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `coldept`
--

INSERT INTO `coldept` (`id_no`, `college`, `department`) VALUES
(1, 'CAST', 'Computer Science'),
(2, 'CAST', 'Computer Engineering'),
(3, 'CAST', 'Psychology'),
(4, 'CAST', 'General Education'),
(5, 'CBMA', 'Accountancy'),
(6, 'CBMA', 'Business Administration'),
(7, 'CBMA', 'Tourism Management'),
(8, 'CBMA', 'Hospitality Management'),
(9, 'CVMAS', 'Veterinary Medicine'),
(10, 'CVMAS', 'Food Technology'),
(11, 'CoED', 'Education'),
(12, 'CAST', 'none'),
(13, 'CBMA', 'none'),
(14, 'CVMAS', 'none'),
(15, 'CoED', 'none'),
(16, 'none', 'none');

-- --------------------------------------------------------

--
-- Table structure for table `currentsem`
--

CREATE TABLE `currentsem` (
  `Term_ID` int(11) NOT NULL,
  `Term` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `currentsem`
--

INSERT INTO `currentsem` (`Term_ID`, `Term`) VALUES
(1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `dean`
--

CREATE TABLE `dean` (
  `IDnum` varchar(20) NOT NULL,
  `College` text NOT NULL,
  `Dean` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `dean`
--

INSERT INTO `dean` (`IDnum`, `College`, `Dean`) VALUES
('07-196-12', 'CAST', 'Marilyn Rubrica'),
('01-000-01', 'CoED', 'Analiza Falculan'),
('01-000-03', 'CVMAS', 'Antonio Glinoga'),
('01-000-02', 'CBMA', 'Glen De Leon');

-- --------------------------------------------------------

--
-- Table structure for table `faculty`
--

CREATE TABLE `faculty` (
  `Idnum` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `firstname` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `lastname` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `passcode` varchar(30) DEFAULT NULL,
  `status` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `management` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `College` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `Department` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `WorkStatus` varchar(30) CHARACTER SET utf8 DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `faculty`
--

INSERT INTO `faculty` (`Idnum`, `firstname`, `lastname`, `passcode`, `status`, `management`, `College`, `Department`, `WorkStatus`) VALUES
('07-179-01', 'Alex', 'Pasion', '1234', 'active', 'No', 'CAST ', ' Computer Science', 'PERMANENT'),
('07-196-12', 'Marilyn', 'Rubrica', '1234', 'active', 'Yes', 'CAST ', ' Computer Science', 'PERMANENT'),
('01-000-01', 'Analiza', 'Falculan', '1234', 'active', 'Yes', 'CoED ', ' Education', 'PERMANENT'),
('01-000-02', 'Glen', 'De Leon', '1234', 'active', 'Yes', 'CBMA ', ' Accountancy', 'PERMANENT'),
('01-000-03', 'Antonio', 'Glinoga', '1234', 'active', 'Yes', 'CVMAS ', ' none', 'PERMANENT'),
('01-000-04', 'Querobin', 'Dycoco', '1234', 'active', 'Yes', 'CVMAS ', ' Veterinary Medicine', 'PERMANENT'),
('01-000-05', 'Evangeline', 'dela Cruz', '1234', 'inactive', 'Yes', 'none ', ' none', 'PERMANENT'),
('01-000-06', 'Ronald', 'Ibarlin', '1234', 'active', 'Yes', 'none ', ' none', 'PERMANENT'),
('01-000-07', 'Bernardo', 'Sepeda', '1234', 'active', 'Yes', 'none ', ' none', 'PERMANENT');

-- --------------------------------------------------------

--
-- Table structure for table `management`
--

CREATE TABLE `management` (
  `IDnum` varchar(20) NOT NULL,
  `name` text NOT NULL,
  `position` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `management`
--

INSERT INTO `management` (`IDnum`, `name`, `position`) VALUES
('01-000-05', 'Evangeline dela Cruz', 'Registrar'),
('01-000-06', 'Ronald Ibarlin', 'HR head'),
('01-000-07', 'Bernardo Sepeda', 'VCAR');

-- --------------------------------------------------------

--
-- Table structure for table `programchair`
--

CREATE TABLE `programchair` (
  `IDnum` varchar(20) NOT NULL,
  `Department` text NOT NULL,
  `ProgramChair` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `programchair`
--

INSERT INTO `programchair` (`IDnum`, `Department`, `ProgramChair`) VALUES
('07-196-12', 'Computer Science', 'Marilyn Rubrica'),
('01-000-01', 'Secondary Education', 'Analiza Falculan'),
('01-000-04', 'Veterinary Medicine', 'Querobin Dycoco'),
('01-000-02', 'Accountancy', 'Glen De Leon');

-- --------------------------------------------------------

--
-- Table structure for table `timetable`
--

CREATE TABLE `timetable` (
  `SubjectCode` varchar(20) NOT NULL,
  `Description` text NOT NULL,
  `Section` varchar(20) NOT NULL,
  `StartTime` time NOT NULL,
  `EndTime` time NOT NULL,
  `Day` varchar(15) NOT NULL,
  `daycount` int(11) NOT NULL,
  `Units` int(11) NOT NULL,
  `ClassType` varchar(5) NOT NULL,
  `Idnum` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `timetable`
--

INSERT INTO `timetable` (`SubjectCode`, `Description`, `Section`, `StartTime`, `EndTime`, `Day`, `daycount`, `Units`, `ClassType`, `Idnum`) VALUES
('ITC101', 'Intro to Computing', 'BSCS1A', '07:30:00', '08:50:00', 'M, W, F', 3, 3, 'R', '07-179-01'),
('ITS201', 'Intro to Statistics', 'BSCS2A', '08:50:00', '10:10:00', 'M, W, F', 3, 3, 'R', '07-179-01'),
('PROG101A', 'Programming 101 Lec', 'BSCS1A', '12:50:00', '14:10:00', 'M, W', 2, 3, 'R', '07-179-01'),
('ETS101', 'Emerging Technologies in Society', 'BSCS1A', '10:10:00', '11:30:00', 'M, W, F', 3, 3, 'R', '07-179-01'),
('PROG101B', 'Programming 101 Lab', 'BSCS1A', '13:30:00', '17:30:00', 'F', 1, 1, 'R', '07-179-01'),
('CE101', 'Computer Lab Etiquette', 'BSCS1A', '07:30:00', '08:50:00', 'T', 1, 1, 'R', '07-179-01'),
('AJP201B', 'Advanced Java Programming Lab', 'BSCS2A', '09:30:00', '11:30:00', 'T, H', 2, 1, 'R', '07-179-01'),
('C1', 'Consultation', 'N/A', '14:10:00', '15:30:00', 'M, W, ', 2, 0, 'C', '07-179-01'),
('C2', 'Consultation', 'N/A', '08:50:00', '09:30:00', 'T, ', 1, 0, 'C', '07-179-01'),
('C3', 'Consultation', 'N/A', '11:30:00', '12:50:00', 'M, W, ', 2, 0, 'C', '07-179-01'),
('OC2', 'Off-Campus', 'N/A', '14:00:00', '16:30:00', 'H, ', 1, 0, 'OC', '07-179-01'),
('OH1', 'Office Hours', 'N/A', '11:30:00', '15:30:00', 'T, ', 1, 0, 'OH', '07-179-01'),
('OH2', 'Office Hours', 'N/A', '11:30:00', '14:00:00', 'H, ', 1, 0, 'OH', '07-179-01'),
('OH4', 'Office Hours', 'N/A', '15:30:00', '16:00:00', 'M, W, ', 2, 0, 'OH', '07-179-01');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `user_id` int(11) NOT NULL,
  `firstname` varchar(50) NOT NULL,
  `lastname` varchar(50) NOT NULL,
  `username` varchar(20) NOT NULL,
  `password` varchar(50) NOT NULL,
  `status` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`user_id`, `firstname`, `lastname`, `username`, `password`, `status`) VALUES
(1, 'Administrator', '', 'admin', '21232f297a57a5a743894a0e4a801fc3', 'administrator'),
(4, 'Johann Sebastian', 'Bucks', 'johannbucks', '81dc9bdb52d04dc20036dbd8313ed055', 'Regular'),
(5, 'Hazel', 'Bigcas', 'Hazel', '81dc9bdb52d04dc20036dbd8313ed055', 'Regular');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
