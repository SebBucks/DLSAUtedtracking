<!DOCTYPE html>
<?php 
	require 'validator.php';
	require_once 'conn.php'
	
?>
<html lang = "en">
	<head>
		<title>TED Teaching Load Tracking</title>
		<meta charset = "utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel = "stylesheet" type = "text/css" href = "css/bootstrap.css" />
		<link rel = "stylesheet" type = "text/css" href = "css/jquery.dataTables.css" />
		<link rel = "stylesheet" type = "text/css" href = "css/style.css" />
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
	</head>
<body>
<?php
function fill_college($conn)  
 {  
      $output = '';  
      $sql = "SELECT * FROM coldept";  
      $result = mysqli_query($conn, $sql);  
      while($row = mysqli_fetch_array($result))  
      {   	
           $output .= '<option value="'.$row["college"]." -- ". $row["department"].'">'.$row["college"]." -- ". $row["department"].'</option>';    
      }  
      return $output;  
 } 
?>
	<nav class="navbar navbar-default navbar-fixed-top" style="background-color:green;">
		<div class="container-fluid">
			<label class="navbar-brand" id="title">TED Teaching Load Tracking</label>
			<?php 
				$query = mysqli_query($conn, "SELECT * FROM `user` WHERE `user_id` = '$_SESSION[user]'") or die(mysqli_error());
				$fetch = mysqli_fetch_array($query);
			?>
			<ul class = "nav navbar-right">	
				<li class = "dropdown">
					<a class = "user dropdown-toggle" data-toggle = "dropdown" href = "#">
						<span class = "glyphicon glyphicon-user"></span>
						<?php 
							echo $fetch['firstname']." ".$fetch['lastname'];
						?>
						<b class = "caret"></b>
					</a>
				<ul class = "dropdown-menu">
					<li>
						<a href = "logout.php"><i class = "glyphicon glyphicon-log-out"></i> Logout</a>
					</li>
				</ul>
				</li>
			</ul>
		</div>
	</nav>
	<?php include 'sidebar.php'?>
	<div id = "content">
		<br /><br /><br />
		<div class="alert alert-info"><h3>Faculty</h3></div> 
		<button class="btn btn-success" data-toggle="modal" data-target="#form_modal"><span class="glyphicon glyphicon-plus"></span> Add Faculty</button>
		<br /><br />
		<table id = "table" class="table table-bordered">
			<thead>
				<tr>
					<th>IDnum</th>
					<th>Firstname</th>
					<th>Lastname</th>
					<th>Password</th>
					<th>Status</th>
					<th>Management</th>
					<th>College</th>
					<th>Department</th>
					<th>WorkStatus</th>
				</tr>
			</thead>
			<tbody>
				<?php
				
					$query = mysqli_query($conn, "SELECT * FROM `faculty`") or die(mysqli_error());
					while($fetch = mysqli_fetch_array($query)){
				?>
					<tr class="del_faculty<?php echo $fetch['Idnum']?>">
						<td><?php echo $fetch['Idnum']?></td>
						<td><?php echo $fetch['firstname']?></td>
						<td><?php echo $fetch['lastname']?></td>
						<td>********</td>
						<td><?php echo $fetch['status']?></td>
						<td><?php echo $fetch['management']?></td>
						<td><?php echo $fetch['College']?></td>
						<td><?php echo $fetch['Department']?></td>
						<td><?php echo $fetch['WorkStatus']?></td>
						
						<td><center><button class="btn btn-warning" data-toggle="modal" data-target="#edit_modal<?php echo $fetch['Idnum']?>"><span class="glyphicon glyphicon-edit"></span> Edit</button> 
						<button class="btn btn-danger" data-toggle="modal" data-target="#delete_modal<?php echo $fetch['Idnum']?>" type="button"><span class="glyphicon glyphicon-trash"></span> Delete</button></center>
						</td>
						<td>
						<center><button class="btn btn-warning" data-toggle="modal" data-target="#signature_modal<?php echo $fetch['Idnum']?>"><span class="glyphicon glyphicon-edit"></span>Change Signature</button> 
						</td>
					</tr>
	<div class="modal fade" id="edit_modal<?php echo $fetch['Idnum']?>" aria-hidden="true">
		<div class="modal-dialog modal-dialog-centered">
			
        <div class="modal-content"> 
          <form method="POST" action="update_faculty.php" enctype="multipart/form-data">
            <div class="modal-header"> 
              <h4 class="modal-title">Update Faculty</h4>
            </div>
            <div class="modal-body"> 
              <div class="col-md-15"> 
                <div class="form-group"> 
                  <label>ID Number </label>
                  <input type="text" name="idnum" value="<?php echo $fetch['Idnum']?>" class="form-control" required="required"/>
                </div>
                <div class="form-group"> 
                  <label>Firstname</label>
                  <input type="text" name="firstname" value="<?php echo $fetch['firstname']?>" class="form-control" required="required"/>
                </div>
                <div class="form-group"> 
                  <label>Lastname</label>
                  <input type="text" name="lastname" value="<?php echo $fetch['lastname']?>" class="form-control" required="required"/>
                </div>
                <div class="form-group"> 
                  <label>Status</label>
                  <select name="status" class="form-control" required="required" >
                    <option value="inactive" <?php echo ($fetch['status'] == 'inactive' ? ' selected="selected"' : ''); ?>>Inactive</option>
                    <option value="active" <?php echo ($fetch['status'] == 'active' ? ' selected="selected"' : ''); ?>>Active</option>
                  </select>
                </div>
                <div class="form-group"> 
                  <label>College and Department</label>
                  <select id="coldept" name="coldept" class="form-control" required="required">
                    <?php  $output = '';  
						  $result = mysqli_query($conn, "SELECT * FROM `faculty` where Idnum = '$fetch[Idnum]'") or die(mysqli_error());
						  $printres = mysqli_fetch_array($result);
						  $editcollege = $printres['College'];
						  $editdept = $printres['Department'];
						  $edittext = $printres['College']." -- ". $printres['Department'];
						  $selected= '';
						  $sql = "SELECT * FROM coldept";  
						  $result = mysqli_query($conn, $sql);  
						  while($row = mysqli_fetch_array($result))  
						  {   
								$valuetext = $row["college"]." -- ". $row["department"];
								if ($valuetext == $edittext){
								$selected = ' selected="selected"';
								}else{
								$selected= '';
								}	
							   echo '<option value="'.$row["college"]." -- ". $row["department"].'"'. $selected.' >'
									   .$row["college"]." -- ". $row["department"].'</option>';    
						  }  
				   ?>
                  </select>
                </div>
                <div class="form-group"> 
                  <label>Work Status</label>
                  <select name="workstatus" class="form-control" required="required">
                    <option value="PARTTIME"<?php if ($fetch['WorkStatus'] == 'PARTTIME') echo ' selected="selected"'; ?>>Part-Time 
                    </option>
                    <option value="PERMANENT" <?php if ($fetch['WorkStatus'] == 'PERMANENT') echo ' selected="selected"'; ?>>Permanent</option>
                    <option value="PROBATIONARY"<?php if ($fetch['WorkStatus'] == 'PROBATIONARY') echo ' selected="selected"'; ?>>Probationary</option>
                  </select>
                </div>
              </div>
              <div class="form-group"> 
                <label>Password</label>
                <input type="password" name="password" class="form-control" required="required"/>
              </div>
              <input type="hidden" name="rowid" value="<?php echo $fetch['row_id']?>">
            </div>
            <div style="clear:both;"></div>
            <div class="modal-footer"> 
              <button type="button" class="btn btn-danger" data-dismiss="modal"><span class="glyphicon glyphicon-remove"></span> 
              Close</button>
              <button name="update" id="update" class="btn btn-warning" ><span class="glyphicon glyphicon-save"></span> 
              Update</button>
            </div>
          </form>
        </div>
		</div>
	</div>
	<?php include 'delete_modal.php'?>
	<?php include 'signature_modal.php'?>
				<?php
					}
				?>
			</tbody>
		</table>
		<?php 
		echo '</br>'; 
		echo '</br>';
		echo '</br>';
		echo '</br>';
		?>
	</div>
	
	<div class="modal fade" id="form_modal" aria-hidden="true">
		<div class="modal-dialog modal-dialog-centered">
			
    <div class="modal-content"> 
      <form method="POST" action="save_faculty.php" enctype="multipart/form-data">
        <div class="modal-header"> 
          <h4 class="modal-title">Add Faculty</h4>
        </div>
        <div class="modal-body"> 
          <div class="col-md-15"> 
            <div class="form-group"> 
              <label>ID Number </label>
              <input type="text" name="idnum" class="form-control" required="required"/>
            </div>
            <div class="form-group"> 
              <label>Firstname</label>
              <input type="text" name="firstname" class="form-control" required="required"/>
            </div>
            <div class="form-group"> 
              <label>Lastname</label>
              <input type="text" name="lastname" class="form-control" required="required"/>
            </div>
            <div class="form-group"> 
              <label>Status</label>
              <select name="status" class="form-control" required="required" >
                <option value="inactive" >Inactive</option>
                <option value="active" >Active</option>
              </select>
            </div>
            <div class="form-group"> 
              <label>College and Department</label>
              <select id="coldept" name="coldept" class="form-control" required="required">
                <?php echo fill_college($conn);?> 
              </select>
            </div>
            <div class="form-group"> 
              <label>Work Status</label>
              <select name="workstatus" class="form-control" required="required">
                <option value="PARTTIME">Part-Time </option>
                <option value="PERMANENT">Permanent</option>
                <option value="PROBATIONARY">Probationary</option>
              </select>
            </div>
            <div class="form-group"> 
              <label>Signature</label>
              <input type="file" name="file" required="required">
            </div>
          </div>
          <div class="form-group"> 
            <label>Password</label>
            <input type="password" name="password" class="form-control" required="required"/>
          </div>
        </div>
        <div style="clear:both;"></div>
        <div class="modal-footer"> 
          <button type="button" class="btn btn-danger" data-dismiss="modal"><span class="glyphicon glyphicon-remove"></span> 
          Close</button>
          <button name="add" id="add" class="btn btn-success" ><span class="glyphicon glyphicon-plus"></span> 
          Add</button>
        </div>
      </form>
      
	
    </div>
		</div>
	</div>
	
	<div id = "footer">
		<label class = "footer-title">&copy; Copyright TED Teaching Load Tracking <?php echo date("Y", strtotime("+8 HOURS"))?></label>
	</div>
<?php include 'script.php'?>
<script type="text/javascript">
$(document).ready(function(){
	$('.btn-delete').on('click', function(){
		var Idnum = $(this).attr('id');
		$("#modal_confirm").modal('show');
		$('#btn_yes').attr('name', Idnum);
	});
	
	$('#btn_yes').on('click', function(){
		var id = $(this).attr('name');
		$.ajax({
			type: "POST",
			url: "delete_faculty.php",
			data:{Idnum: id},
			success: function(){
				$("#modal_confirm").modal('hide');
				$(".del_faculty" + id).empty();
				$(".del_faculty" + id).html("<td colspan='6'><center class='text-danger'>Deleting...</center></td>");
				setTimeout(function(){
					$(".del_faculty" + id).fadeOut('slow');
				}, 1000);
			}
		});
	});		
});
</script>	
</body>
</html>