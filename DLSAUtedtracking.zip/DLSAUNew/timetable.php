<style>
cld{
    display: inline;
    font-size: 20px;
}
</style> 

<p class="pull-left"><cld>Color Legend:</cld> <cld style="color:#65ff94;">Regular Load = Green</cld>, <cld style="color:#FFA500;">Overload = Orange</cld>,  <cld style="color:#88f1fe;">Consultation time = Cyan</cld>, <cld style="color:#479af9;">Office Hours = Blue</cld>, <cld style="color:#b58a44;">Off-Campus = Brown</cld>, <cld style="color:#808080;">Requested tutorial = Gray</cld>, <cld style="color:#FFC0CB;">Converted Tutorial = Pink</cld></p>
<table class="table table-bordered">
	<tr>
    	<th> </th>
   	<th >Monday</th>
	<th >Tuesday</th>
	<th >Wednesday</th>
	<th >Thursday</th>
	<th >Friday</th>
	<th >Saturday</th>
 	</tr>
<?php 

$time = array( '07:30','08:50','09:30', '10:10', '11:30','12:50','13:30', '14:10', '15:30', '16:50', '17:30');

 $query=mysqli_query($conn,"select * from timetable where Idnum = '$_SESSION[faculty]'")or die(mysqli_error());
while($fetch = mysqli_fetch_array($query)){
$strstart= strtotime($fetch['StartTime']);
$strend= strtotime($fetch['EndTime']);
array_push($time,date("H:i", $strstart),date("H:i",$strend ));
}
$time = array_unique($time);


$strtime = [];
	foreach($time as $count =>$i){
		$i = strtotime($i);
		$strtime[$count] = $i;
		//echo $strtime[$count] . '<br/>';
		}
		
echo '<br/>';		
sort($strtime);
$strtimecount = count($strtime) ;
	for ($a = 0; $a < $strtimecount-1; $a++){
	
		//echo date('H:i',$a) . '<br/>';
		//$timedisplay = date('H:i',$a);
		$strcountend = $a + 1;
		$cellstart = $strtime[$a];
		$cellend = $strtime[$strcountend];
		
		//echo 'Cellstart '. $a . ' = ' .$cellstart;
		//echo 'Cellend '. $a . ' = ' .$cellend;
		//echo '<br/>';
 
?>
		<tr>
    		<td><?php echo date('H:i',$strtime[$a]) . '<br/>';?></td>
   			<td> <?php $cellday = 'M'; ?><?php include 'timetable_cell.php'?></td>
			<td><?php $cellday = 'T';?><?php include 'timetable_cell.php'?></td>
			<td><?php $cellday = 'W';?><?php include 'timetable_cell.php'?></td>
			<td><?php $cellday = 'H';?><?php include 'timetable_cell.php'?></td>
			<td><?php $cellday = 'F';?><?php include 'timetable_cell.php'?></td>
			<td><?php $cellday = 'S';?><?php include 'timetable_cell.php'?></td>
 		</tr>
<?php
	}
?>


<tr>
    		<td ><?php echo date('H:i',$strtime[$strtimecount-1]);?></td>
    	<td colspan="6"></td>
</tr>
</table>
