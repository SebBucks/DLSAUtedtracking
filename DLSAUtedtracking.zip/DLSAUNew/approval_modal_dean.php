<div class="modal fade" id="approve_dean" aria-hidden="true">
	<div class="modal-dialog modal-dialog-centered">		
    	<div class="modal-content"> 
		 <div class="modal-header"> 
        <h3 class="modal-title">System</h3>
      <div class="modal-body"> 
        <center>
          <h4>Approve Schedule?</h4>
        </center>
      </div>
	  	<div class="modal-footer"> 
        	<a href="approval_ok_dean.php" class="btn btn-success">Submit</a> 
			<a type="button" class="btn btn-danger" data-dismiss="modal">Cancel</a> 
		</div>
		</div>
	</div>
</div>
</div>