<div class="modal fade" id="delete_time" aria-hidden="true">
		<div class="modal-dialog modal-dialog-centered">
    <div class="modal-content"> 
	<form method="POST" action="delete_time.php">
      <div class="modal-header"> 
        <h3 class="modal-title">System</h3>
      </div>
      <div class="modal-body"> 
        <center>
          <h4 class="text-danger">Are you sure you want to delete this data?</h4>
        </center>
      </div>
      <div class="modal-footer"> 
	  <input type='hidden' name='subject' id='subject' value='test' />
		<button type="button" class="btn btn-danger" data-dismiss="modal"><span class="glyphicon glyphicon-remove"></span> 
          Close</button>
          <button name="btn_yes" id="btn_yes" class="btn btn-success" ><span class="glyphicon glyphicon-trash"></span> 
          Yes</button>
      </div>
	  </form>
    </div>
		</div>
	</div>