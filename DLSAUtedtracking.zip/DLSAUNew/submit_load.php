<?php 
session_start();
require_once 'admin/conn.php';

function alert($msg) {
    echo "<script type='text/javascript'>alert('$msg');</script>";
}
$query=mysqli_query($conn,"select * from faculty where Idnum = '$_SESSION[faculty]'")or die(mysqli_error());
$fetch=mysqli_fetch_array($query);
$workstatus = $fetch['WorkStatus'];
		
$computenum = $_SESSION['submitnum'];
 //if($workstatus == "PARTTIME"){
	//  if($computenum >= 40)
	//  {
	//	alert('Invalid, Please check your schedule');
	//	echo "<script>window.location = 'profile.php'</script>";
	//	}else
	//	{
		mysqli_query($conn, "UPDATE `approval` SET submitted='ok', reject = '--' Where IDnum = '$_SESSION[faculty]'") or die(mysqli_error());
		alert('Schedule submitted');
		echo "<script>window.location = 'profile.php'</script>";
	//	}
 //}else{
    //  if($computenum >= '40')
	//	{
	//	mysqli_query($conn, "UPDATE `approval` SET submitted='ok', reject = '--' Where IDnum = '$_SESSION[faculty]'") or die(mysqli_error());
	//	alert('Schedule submitted');
	//	echo "<script>window.location = 'profile.php'</script>";	
	//	}else
	//	{
	//	alert('Invalid, Please check your schedule');
	//	echo "<script>window.location = 'profile.php'</script>";
	//	}
//}

?>