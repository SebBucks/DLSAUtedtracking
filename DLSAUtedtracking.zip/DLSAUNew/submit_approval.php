<div class="modal fade" id="submit_approval" aria-hidden="true">
	<div class="modal-dialog modal-dialog-centered">		
    	<div class="modal-content"> 
		 <div class="modal-header"> 
		 </div>
        <h3 class="modal-title">System</h3>
      <div class="modal-body"> 
        <center>
          
          <?php 
	  if($workstatus == "PARTTIME"){
				if($grandinteger >= 40)
				{
				echo '<h4>You have invalid loads(Overload/Underload). Submit Schedule?</h4>';
				}else
				{
				echo '<h4>Submit Schedule?</h4>';
				}
		 }else{	
			  if($grandinteger == 40)
			  {
			  echo '<h4>Submit Schedule?</h4>';
			  }else
			  {
			  echo '<h4>You have invalid loads(Overload/Underload). Submit Schedule?</h4>';
			  }  
		}
	   ?>
        </center>
      </div>
	  <div class="modal-footer"> <a type="button" class="btn btn-danger" data-dismiss="modal">Cancel</a> 
        <a href="submit_load.php" class="btn btn-success">Submit</a> </div>
		</div>
	</div>
</div>
