<h4 style="color:red;">Load Assignment</h4>
 <?php
 $approval = '';
 $reject = '';
			$query1 = mysqli_query($conn, "SELECT * FROM `approval` WHERE IDnum = '$_SESSION[faculty]' ") or die(mysqli_error());				
			while($fetch1 = mysqli_fetch_array($query1))
			{
			$approval = $fetch1['submitted'];
			$reject = $fetch1['reject'];
			}
			if($reject != '--')
			{
			echo '<h4 style="color:red;">Remarks:'. $reject. '</h4>';
			}
	  ?>
<table id= "table" class="table table-bordered">
        <thead>
          <tr> 
            <th>SubjectCode</th>
            <th>Description</th>
			 <th>Section</th>
            <th>StartTime</th>
            <th>EndTime</th>
            <th>Day</th>
            <th>ClassType</th>
            <th>Hours</th>
			<?php
			if($approval != 'ok')
				{
			echo '<th></th>';
			}
			?>
          </tr>
        </thead>
        <tbody id = "tablebody">
          <?php
	       
        	 
        	  			
        
        	$total = '';  
			$Idnum = $_SESSION['faculty'];
			$idcheck = $Idnum;
			$query = mysqli_query($conn, "SELECT * FROM timetable WHERE Idnum = '$Idnum' ") or die(mysqli_error());				
			while($fetch = mysqli_fetch_array($query)){	
						?>
          <tr class="del_user<?php echo $fetch['SubjectCode']?>"> 
            <td><?php echo $fetch['SubjectCode']?></td>
            <td><?php echo $fetch['Description']?></td>
            <td><?php echo $fetch['Section']?></td>
            <td><?php echo date("H:i",strtotime($fetch['StartTime']))?></td>
            <td><?php echo date("H:i",strtotime($fetch['EndTime']))?></td>
            <td><?php echo $fetch['Day']?></td>
            <td><?php echo $fetch['ClassType']?></td>
            <?php
            
              $starttime= decimalHours($fetch['StartTime']);
        	  $endtime= decimalHours($fetch['EndTime']);
        	  $output = $endtime-$starttime;
        	  $output = $output * $fetch['daycount'];
        	  $total = $total + $output;	
            ?>
            <td><?php echo round($output,2)?></td>
            
            
			<?php
				if($approval != 'ok')
				{
					echo '<td>';	
						if ($fetch['ClassType'] != 'R' && $fetch['ClassType'] != 'O' && $fetch['ClassType'] != 'CT'&& $fetch['ClassType'] != 'RT') 
						{
						?><button class="btn btn-warning" data-toggle="modal" data-target="#edit_modal<?php echo $fetch['SubjectCode']; ?>"><span class="glyphicon glyphicon-edit"></span> Edit</button>	
						<a href="delete_time.php?id='<?php echo $fetch['SubjectCode'];?>'" class="btn btn-danger"><span class="glyphicon glyphicon-trash">Delete</a>
						<?php 
						}
					echo '</td>';
				}
			?>	
          </tr>
		  <?php include 'edit_time.php' ?>
		  
		  <?php
		   }
		   ?>
        </tbody>
      </table>
<?php $query = mysqli_query($conn, "SELECT * FROM `approval` WHERE `IDnum` = '$_SESSION[faculty]'") or die(mysqli_error());
			$fetch = mysqli_fetch_array($query);
			
			
			 $addcons = 0;
	  $query1 = mysqli_query($conn, "SELECT * FROM `timetable` WHERE `ClassType` = 'R' OR `ClassType` = 'O' OR `ClassType` = 'RT' OR `ClassType` = 'CT'") or die(mysqli_error());
		    while($fetch1 = mysqli_fetch_array($query1)){
			if($fetch1['Idnum'] == $_SESSION['faculty']){
			$addcons = $addcons + 1;
			}
			}
			?>
  <?php 	 
  if($fetch['submitted'] == 'ok' || $fetch['progchair'] == 'ok' ||  $addcons == 0)
	{ 
	echo '<button class="btn btn-success" disabled><span class="glyphicon glyphicon-plus"></span> Add Time</button>';
	}else
	{
	echo '<button class="btn btn-success" data-toggle="modal" data-target="#form_addtime"><span class="glyphicon glyphicon-plus"></span> Add Time</button>';
	}

?>
<button class="btn btn-success" data-toggle="modal" data-target="#updater<?php echo $idcheck?>"><span class="glyphicon glyphicon-save"></span>
		 Update Loads</button>
		 
