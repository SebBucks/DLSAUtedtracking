<div class="modal fade" id="updater<?php echo $idcheck?>" aria-hidden="true">
	<div class="modal-dialog modal-dialog-centered">		
    	<div class="modal-content"> 
		 <div class="modal-header">
		 </div><form class="form-horizontal well" method="POST" action="progchair_load_updater_ok.php" enctype="multipart/form-data"> 
        <h3 class="modal-title">System</h3>
      <div class="modal-body"> 
        <center>
          <h4>Upload New Load Set</h4>
        </center>	
		<div class="control-group">
				<div class="pull-left">
					<label>CSV File:   </label>
				</div>
				<div class="controls">
					<input type="file" name="file" id="file" class="input-large"  accept=".csv,.xlsx">
					<input type="hidden" name="load" value="<?php echo $idcheck?>">
				</div>
				</br>
				</br>
				Download Sample File:
				<a href="download_csv.php?file=UploadSample.csv">UploadSample.csv</a>
				Guide Image:
				<a href="csv_sample_img.php"  target="_blank">CSV picture guide</a>
				</br>
				</br>
				<center><label>Note: Use this csv file and picture as a guide and replace the contents inside it based on the guide</label></center>
					<center>
          <h4 class="text-danger">Uploading new loads will delete the contents of the current time table for this faculty member. Please double check before updating.</h4>		 
        </center>
		</div>
      </div>
	  	<div class="modal-footer"> 
       
          <button name="import" id="import" class="btn btn-success" ><span class="glyphicon glyphicon-save"></span> 
          Update</button>
		  <button type="button" class="btn btn-danger" data-dismiss="modal"><span class="glyphicon glyphicon-remove"></span> 
          Close</button>
		  </form>
		</div>
		</div>
	</div>
</div>
</div>