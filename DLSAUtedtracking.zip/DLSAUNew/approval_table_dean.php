<h3>Dean Approval</h3>
<table id= "table2"  tableclass="table table-bordered">
<?php 
$idcheck = '';
$college = ''; 
$faccol = '';
$approvalcheck = '';
?>
<?php
	$idnum = $_SESSION['faculty'];
			$query = mysqli_query($conn, "SELECT * FROM dean WHERE IDnum = '$idnum' ") or die(mysqli_error());				
			while($fetch = mysqli_fetch_array($query)){
				$college = trim($fetch['College']);
				}
						?>
        <thead>
          <tr> 
            <th>ID number</th>
			<th>Name</th>
			<th>Check Schedule</th>
			</tr>			
        </thead>
        <tbody id = "tablebody" >
		<?php
			$query1 = mysqli_query($conn, "SELECT * FROM approval WHERE progsub = 'ok' ") or die(mysqli_error());				
			while($fetch1 = mysqli_fetch_array($query1)){
				$idcheck = $fetch1['IDnum']; 
				$approvalcheck = $fetch1['deansub'];	
					?>
		
		 <?php
		 
		if($approvalcheck <> 'ok'){
				//echo '<td></td><td></td><td></td>';
			//	}else{//approvalcheck else start
				?>
		 <?php
			$query = mysqli_query($conn, "SELECT * FROM faculty WHERE Idnum = '$idcheck' ") or die(mysqli_error());				
			while($fetch = mysqli_fetch_array($query)){//while start
				$faccol = trim($fetch['College']);
					if ($college == $faccol){
					
						?>
		<tr class="del_user<?php echo $idcheck?>">
         <td><?php echo $idcheck?></td>
		 <td><?php echo $fetch['firstname']?> <?php echo " " ?><?php echo $fetch['lastname']?></td>   
		
	 <td><a href="approval_view_dean.php?id='<?php echo $fetch['Idnum']?>'" target="_blank" class="btn btn-warning"><span class="glyphicon glyphicon-edit">Check</a></td> 
		
		</tr>
		<?php 
				}
			}//while end
		}//approvalcheck end	
	} 
		?> 
	    </tbody>
      </table>