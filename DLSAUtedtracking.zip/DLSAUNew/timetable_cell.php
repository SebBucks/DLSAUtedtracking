<?php

 $StartArray = [];
 $EndArray = [];
 $classtype= '';
 $bgcolor = '';

 
	 $query=mysqli_query($conn,"select * from timetable where Idnum = '$_SESSION[faculty]' and day like '%$cellday%'")or die(mysqli_error());
	  while($fetch = mysqli_fetch_array($query)){
	      $StartArray[] = strtotime($fetch['StartTime']); 
	      $EndArray[] = strtotime($fetch['EndTime']) ;
	 }


$closeststart = strtotime('24:00:00');
$closestend= strtotime('24:00:00');
    foreach($StartArray as $day)
    {

		if($day <= $cellstart){
        $interval = abs($cellstart - $day);
			
			if($closeststart>$interval){
			$ResultStart = $day;
			$closeststart = $interval;
			}


		}
    }
	//echo date("H:i:s",$ResultStart).'<br>';

    foreach($EndArray as $day)
    {

		if($cellend <= $day ){
        $interval = abs($day- $cellend);
		
			if($closestend>$interval){
			$ResultEnd = $day;
			$closestend = $interval;
			}
		}
    }
  // echo date("H:i:s",$ResultEnd).'<br>';	
 

$FinalStart =  date("H:i",$ResultStart);
$FinalEnd = date("H:i",$ResultEnd);
$StartId = '';
$EndId = '';



$query=mysqli_query($conn,"select * from timetable where Idnum = '$_SESSION[faculty]' AND StartTime = '$FinalStart' and day like '%$cellday%'")or die(mysqli_error($conn));
$fetch = mysqli_fetch_array($query);
$StartId = $fetch['subj_id'];
$Subjcode = $fetch['SubjectCode'];
$classtype = $fetch['ClassType'];

$query=mysqli_query($conn,"select * from timetable where Idnum = '$_SESSION[faculty]' AND EndTime = '$FinalEnd' and day like '%$cellday%'")or die(mysqli_error());
$fetch = mysqli_fetch_array($query);
$EndId = $fetch['subj_id'];



//echo date("h:i:sa",$cellstart).'<br>';
//echo date("h:i:sa",$cellend).'<br>';
//echo date("h:i:sa",$FinalStart).'<br>';
//echo date("h:i:sa",$FinalEnd).'<br>';
//echo $StartId.'<br>';
//echo $EndId.'<br>';
//echo $cellday;

//$cStart = date("H:i:s",$cellstart);
//$cEnd = date("H:i:s",$cellend);	
//	  $result=mysqli_query($conn,"select * from timetable where Idnum = '$_SESSION[faculty]' AND StartTime = '$cStart' OR EndTime = '$cEnd' and day like '%$cellday%'")or die(mysqli_error());
//	  $row=mysqli_fetch_array($result);
	  

//	 if($row > 0){
//	 echo 'TEST1';
//			echo '<div style="background-color:#65ff94;">';
			
//		echo $row['SubjectCode'];
//		echo '</br>';	
//		echo $row['StartTime'];
//		echo '</br>';
//	 }
//	 else

if($StartId <> NULL && $EndId <> NULL){
	 if ($StartId == $EndId){
      if($classtype == 'R'){
        $bgcolor = '<div style="background-color:#65ff94;">';//green
      }elseif($classtype == 'O'){
        $bgcolor = '<div style="background-color:#FFA500;">';//orange
      }elseif($classtype == 'RT'){
        $bgcolor = '<div style="background-color:#808080;">';//gray
      }elseif($classtype == 'CT'){
        $bgcolor = '<div style="background-color:#FFC0CB;">';//pink
      }elseif($classtype == 'C'){
        $bgcolor = '<div style="background-color:#88f1fe;">';//cyan
      }elseif($classtype == 'OH'){
        $bgcolor = '<div style="background-color:#479af9;">';//light blue
      }elseif($classtype == 'OC'){
        $bgcolor = '<div style="background-color:#b58a44;">';//brown
      }
        
       echo $bgcolor;	
       echo $Subjcode;
       echo '</br>';	
       echo $FinalStart;
   	   echo '</br>';
       echo $FinalEnd;   
	 }
}	 
	  ?>