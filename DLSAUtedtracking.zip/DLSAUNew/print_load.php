<!DOCTYPE html>
<?php 
	session_start();
	require_once 'admin/conn.php'
?>
<?php	
function decimalHours($time)
{
    $hms = explode(":", $time);
    return ($hms[0] + ($hms[1]/60) + ($hms[2]/3600));
}
?>
<html>
<head>
<title>Print Teaching Load</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<style type="text/css">
div.par {
text-align: center
}
.center {
  margin-left: auto;
  margin-right: auto;
}
.img {
	
	float: left;
	margin-top: 10px;
    width:100px;
    height:100px;
}
.right {
	text-align:right;

}
.left {
	text-align: left;

}	
</style>
<style type="text/css" media="print">
@page {
    size: auto;  
    margin: 0;  
}
</style>
</head>

<body>
<div>
<img class="img" src="admin/images/DLSAU.png">
</div>
<div class="par">
</br>

<p>De La Salle Araneta University </br></p>
<p>Salvador Araneta Campus, Victoneta Ave., Malabon City</p>
</br>
<p>TEACHING LOAD/WORK SCHEDULE PLOTTING FORM</p>
<?php $query = mysqli_query($conn, "SELECT * FROM `effectivitydate` WHERE effdate_id= '1'") or die(mysqli_error());
				$fetch = mysqli_fetch_array($query); ?>

<p>Effectivity Date: <?php echo $fetch['effdate'] ?></p> <!--- code for year --->
<?php
$idnum = $_GET["id"];
$first = rtrim($idnum,"'");
$idtrim = ltrim($first, "'");
$query = mysqli_query($conn, "SELECT * FROM `faculty` WHERE `Idnum` = '$idtrim'") or die(mysqli_error());				
while($fetch = mysqli_fetch_array($query)){
 ?>
<table class="center" width="75%" style="border: 1px solid black; border-collapse: collapse;">
  <tr>
    <td style="border: 1px solid black; border-collapse: collapse;">Name: <?php echo " " . $fetch['firstname']. " " . $fetch['lastname'] ;?> </td><!-- code for name-->
    <td style="border: 1px solid black; border-collapse: collapse;">Status: <?php echo " " . $fetch['WorkStatus']; ?></td><!-- code for status-->
  </tr>
  <tr>
    <td style="border: 1px solid black; border-collapse: collapse;">College/Department:<?php echo " " . $fetch['College'] . " - ". $fetch['Department'] ; ?> </td><!-- code for College-->
	<?php }?>
	<?php
	$result = mysqli_query($conn, "SELECT * FROM `currentsem` WHERE `Term_ID` = '1'") or die(mysqli_error());				
	$row = mysqli_fetch_array($result)
	 ?>
    <td style="border: 1px solid black; border-collapse: collapse;">Term/Period Covered: <?php echo " " . $row['Term']; ?> </td><!-- code for term-->
  </tr>
</table>

<?php include 'print_load_subjects.php' ?>
<?php include 'timetable_print.php'?>
<?php include 'print_load_summary.php' ?>
</br>

<p align="left" style="margin-left:12.5%">SUMMARY OF LOAD: <u><?php echo "R=". $regular . ", O=". $overload. ", RT=". $requested. ", CT=". $converted. 
														  ",C=".$consultation. ", OC=". $offcampus. ", OH=".$officehours. ", TOTAL=". $grandinteger;?></u> </p>
<?php
$officeprint = '';
 $result=mysqli_query($conn,"select * from timetable where IDnum = '$idtrim' AND classtype = 'OH'")or die(mysqli_error());
	  while($row=mysqli_fetch_array($result))
	  {
		$officeprint = 	$officeprint . $row['Day']. $row['StartTime']."-". $row['EndTime']. " ";
	  }?>
<p align="left" style="margin-left:12.5%">OFFICE HOURS: <?php echo $officeprint ?></p>

<?php
$consultprint = '';
 $result=mysqli_query($conn,"select * from timetable where IDnum = '$idtrim' AND classtype = 'C'")or die(mysqli_error());
	  while($row=mysqli_fetch_array($result))
	  {
	  $consultprint = $consultprint . $row['Day']. $row['StartTime']."-". $row['EndTime']. " "; 
	  }?>
<p align="left" style="margin-left:12.5%">CONSULTATION DAY/TIME:<?php echo $consultprint; ?> </p>

</br>
<p align="left" style="margin-left:12.5%"> It is understood that no changes in schedule of classes be made without prior arrangement with this office.</p>

<?php include 'print_load_signatories.php' ?>
<script>window.print()</script>
</div>


</body>
</html>
