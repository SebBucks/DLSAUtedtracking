
 <?php $grandtotal = 0;
 ?>
	<table class="table table-bordered">
 		<tr>
    		<td>Regular Load (R)</td>
   			<td ><?php 
			$starttime='';
			$endtime='';
			$output='';
			$total=0;
	  $result=mysqli_query($conn,"select * from timetable where IDnum = '$idtrim' AND classtype = 'R'")or die(mysqli_error());
	  while($row=mysqli_fetch_array($result))
	  {
	  $starttime= decimalHours($row['StartTime']);
	  $endtime= decimalHours($row['EndTime']);
	  $output = $endtime-$starttime;
	  $output = $output * $row['daycount'];
	  $total = $total + $output;				
	  }
	  echo $total;
	  $grandtotal = $grandtotal + $total;
	  $integer = (int)$total;
	  	
	  ?>
	  </td>
	  <td><?php 
	   $result=mysqli_query($conn,"select * from currentsem where Term_ID = '1'")or die(mysqli_error());
	   $row=mysqli_fetch_array($result);
	  
	  if($row['Term'] == 1)
	  {
	 	 if($workstatus == "PARTTIME"){
			if($integer >= 20)
			{
			echo '<font color=red>Invalid Regular Load';
			}else
			{
			echo '<font color=green>Ok';
			}
		 }else{
			if($integer <> 24)
			{
			echo '<font color=red>Invalid Regular Load';
			}else
			{
			echo '<font color=green>Ok';
			}
		 }
	  }else{
		if($workstatus == "PARTTIME"){
			if($integer >= 20)
			{
			echo '<font color=red>Invalid Regular Load';
			}else
			{
			echo '<font color=green>Ok';
			}
		 }else{
			if($integer <> 20)
			{
			echo '<font color=red>Invalid Regular Load';
			}else
			{
			echo '<font color=green>Ok';
			}
		 }	
	  }
	  ?></td>
 		</tr>
  		<tr>
    		<td>Overload(O)</td>
    		<td><?php 
			$starttime='';
			$endtime='';
			$output='';
			$total=0;
	  $result=mysqli_query($conn,"select * from timetable where IDnum = '$idtrim' AND classtype = 'O'")or die(mysqli_error());
	  while($row=mysqli_fetch_array($result))
	  {
	  $starttime= decimalHours($row['StartTime']);
	  $endtime= decimalHours($row['EndTime']);
	  $output = $endtime-$starttime;
	  $output = $output * $row['daycount'];
	  $total = $total + $output;				
	  }
	  echo $total;
	  $grandtotal = $grandtotal + $total;
	  $integer = (int)$total;	
	  ?></td>
	  <td><?php  
	  	if($integer > 8)
		{
		echo '<font color=red>Invalid Overtime Load';
		}else
		{
		echo '<font color=green>Ok';
		}	
	  ?></td>
  		</tr>
		<tr>
    		<td>Requested tutorial (RT)</td>
    		<td></td>
	  		<td></td>
  		</tr>
		<tr>
    		<td>Converted tutorial (CT)</td>
    		<td></td>
	  		<td></td>
  		</tr>
		<tr>
    		<td>Consultation (C)</td>
    		<td><?php 
			$starttime='';
			$endtime='';
			$output='';
			$total=0;
	  $result=mysqli_query($conn,"select * from timetable where IDnum = '$idtrim' AND classtype = 'C'")or die(mysqli_error());
	  while($row=mysqli_fetch_array($result))
	  {
	  $starttime= decimalHours($row['StartTime']);
	  $endtime= decimalHours($row['EndTime']);
	  $output = $endtime-$starttime;
	  $output = $output * $row['daycount'];
	  $total = $total + $output;				
	  }
	  echo $total;
	  $grandtotal = $grandtotal + $total;
	  $integer = (int)$total;	
	  ?></td>
	  <td><?php 
	  if($integer == 6)
	  {
	  echo '<font color=green>Ok';
	  }else
	  {
	  echo '<font color=red>Consultation Overload/Underload';
	  } 	
	  ?></td>
  		</tr>
		<tr>
    		<td>Off-Campus (OC)</td>
    		<td><?php 
			$starttime='';
			$endtime='';
			$output='';
			$total=0;
	  $result=mysqli_query($conn,"select * from timetable where IDnum = '$idtrim' AND classtype = 'OC'")or die(mysqli_error());
	  while($row=mysqli_fetch_array($result))
	  {
	  $starttime= decimalHours($row['StartTime']);
	  $endtime= decimalHours($row['EndTime']);
	  $output = $endtime-$starttime;
	  $output = $output * $row['daycount'];
	  $total = $total + $output;				
	  }
	  echo $total;
	  $grandtotal = $grandtotal + $total;
	  $integer = $total;	
	  ?></td>
	  <td><?php 
	   $result=mysqli_query($conn,"select * from currentsem where Term_ID = '1'")or die(mysqli_error());
	   $row=mysqli_fetch_array($result);
	  
	  if($row['Term'] = 1)
	  {
	  	if($integer <> '2.5')
	  	{
		echo '<font color=red>Off-Campus Overload/Underload';
		}
	  	else
		{
		echo '<font color=green>Ok';
		}	
	  }else
	  {
	  	if($integer <> '5.5')
	  	{
		echo '<font color=red>Off-Campus Overload/Underload';
		}
	  	else
		{
		echo '<font color=green>Ok';
		}	
	  }
	 
	  ?></td>
  		</tr>
		<tr>
    		<td>Office Hours (OH)</td>
    		<td><?php 
			$starttime='';
			$endtime='';
			$output='';
			$total=0;
	  $result=mysqli_query($conn,"select * from timetable where IDnum = '$idtrim' AND classtype = 'OH'")or die(mysqli_error());
	  while($row=mysqli_fetch_array($result))
	  {
	  $starttime= decimalHours($row['StartTime']);
	  $endtime= decimalHours($row['EndTime']);
	  $output = $endtime-$starttime;
	  $output = $output * $row['daycount'];
	  $total = $total + $output;				
	  }
	  echo $total;
	  $grandtotal = $grandtotal + $total;
	  $integer = $total;	
	  ?></td>
	  <td><?php 
	   $result=mysqli_query($conn,"select * from currentsem where Term_ID = '1'")or die(mysqli_error());
	   $row=mysqli_fetch_array($result);
	  
	  if($row['Term'] = 1)
	  {
	  	if($integer == 7.5)
	 	{
		echo '<font color=green>Ok';
		}
	  	else
		{
		echo '<font color=red>Office Hours Overload/Underload';
		}	
	  }else
	  {
	  if($integer == 8.5)
	 	{
		echo '<font color=green>Ok';
		}
	  	else
		{
		echo '<font color=red>Office Hours Overload/Underload';
		}	
	  }
	 
	  ?></td>
  		</tr>
		<tr>
    		<td>Total</td>
    		<td><?php 	
	  echo $grandtotal;
	  $grandinteger = (int)$grandtotal;
	   	
	  ?></td>
	  <td><?php
	 if($workstatus == "PARTTIME"){
			if($grandinteger >= 40)
			{
			echo '<font color=red>Invalid Regular Load';
			}else
			{
			echo '<font color=green>Ok';
			$_SESSION["submitnum"] = $grandinteger;
			}
	}else{ 
		  if($grandinteger == 40)
		  {
		  echo '<font color=green>Ok';
		  $_SESSION["submitnum"] = $grandinteger;
		  }else
		  {
		  echo '<font color=red>Overload/Underload';
		  }  
	}
	   ?></td>
  		</tr>
  	</table>
	
	