<!DOCTYPE html>
<?php 
	session_start();
	//require 'validator.php';
	require_once 'admin/conn.php'
?>
<?php

function decimalHours($time)
{
    $hms = explode(":", $time);
    return ($hms[0] + ($hms[1]/60) + ($hms[2]/3600));
}
function alert($msg) {
    echo "<script type='text/javascript'>alert('$msg');</script>";
}

?>
<html lang = "en">
	<head>
		<title>TED Teaching Load Tracking</title>
		<meta charset = "utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel = "stylesheet" type = "text/css" href = "admin/css/bootstrap.css" />
		<link rel = "stylesheet" type = "text/css" href = "admin/css/jquery.dataTables.css" />
		<link rel = "stylesheet" type = "text/css" href = "admin/css/style.css" />
		<link rel = "stylesheet" type = "text/css" href = "admin/css/progress-bar.css" />
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
		<style type="text/css">
		.container {
			width: 100%;
		}
		.myprogressbar {
			counter-reset: step;
		}
		.myprogressbar li {
			list-style-type: none;
			float: left;
			width: 16.56%;
			position: relative;
			text-align: center;
		}
		.myprogressbar li:before {
			content: counter(step);
			counter-increment: step;
			width: 30px;
			height: 30px;
			line-height : 30px;
 			border: 1px solid #ddd;
  			border-radius: 50%;
 		 	display: block;
  			text-align: center;
  			margin: 0 auto 10px auto;
  			background-color: #fff;
		}
		.myprogressbar li:after {
  			content: "";
  			position: absolute;
  			width: 100%;
  			height: 1px;
 			background-color: #ddd;
  			top: 15px;
  			left: -50%;
 			z-index : -1;
		}
		.myprogressbar li:first-child:after {
 			content: none;
		}
		.myprogressbar li.active {
 		 	color: green;
		}
		.myprogressbar li.active:before {
  			border-color: green;
		} 
		.myprogressbar li.active + li:after {
 			background-color: green;
		}
			
		</style>
	</head>
	
<body>

	<nav class="navbar navbar-default navbar-fixed-top" style="background-color:green;">
		<div class="container-fluid">
			<label class="navbar-brand" id="title">TED Teaching Load Tracking</label>
			<ul class = "nav navbar-right">	
				<li class = "dropdown">
					<a class = "user dropdown-toggle" data-toggle = "dropdown" href = "#">
						<span class = "glyphicon glyphicon-user"></span>
						<?php 
						$query = mysqli_query($conn, "SELECT * FROM faculty WHERE IDnum = '$_SESSION[faculty]' ") or die(mysqli_error());				
						while($fetch = mysqli_fetch_array($query)){
							echo $fetch['firstname']." ".$fetch['lastname'];
							}
						?>
						<b class = "caret"></b>
					</a>
				<ul class = "dropdown-menu">
				<li>
				<a href = "logout.php"><i class = "glyphicon glyphicon-log-out"></i> Logout</a>
					</li>
				</ul>
				</li>
			</ul>
		</div>
	</nav>
<?php include 'sidebar.php'?>
</br> </br> </br>	
<div class="col-md-4" id="content"> 
  <?php include 'approval_progress.php'?>
  <div  style="float: left; width: 30%" > 
   
    <div class="panel-body"> 
      <h3 style="color:red;">Profile</h3>
          <?php $query = mysqli_query($conn, "SELECT * FROM `schoolyear` WHERE sy_id= '1'") or die(mysqli_error());
				$fetch = mysqli_fetch_array($query); ?>
        <h4> School Year: 
          <label class="pull-right"> <?php echo $fetch['sycurrent'] ?> </label>
        </h4>
        <?php $query = mysqli_query($conn, "SELECT * FROM `currentsem` WHERE Term_ID= '1'") or die(mysqli_error());
				$fetch = mysqli_fetch_array($query); ?>
        <h4>Term: 
          <label class="pull-right"> <?php echo $fetch['Term'] ?> </label>
        </h4>
        
      <?php
			$query = mysqli_query($conn, "SELECT * FROM `faculty` WHERE `IDnum` = '$_SESSION[faculty]'") or die(mysqli_error());
			$fetch = mysqli_fetch_array($query);
		?>
      <h4>ID number: 
        <label class="pull-right"><?php echo $fetch['Idnum']?></label>
      </h4>
      <h4>Name: 
        <label class="pull-right"><?php echo $fetch['firstname']." ".$fetch['lastname']?></label>
      </h4>
      <h4>College: 
        <label class="pull-right"><?php echo $fetch['College']?></label>
      </h4>
      <h4>Department: 
        <label class="pull-right"><?php echo $fetch['Department']?></label>
      </h4>
      <h4>Status: 
        <label class="pull-right"><?php echo $fetch['WorkStatus'] ?></label>
      </h4></br>
      <?php $query = mysqli_query($conn, "SELECT * FROM `programchair` WHERE `Department` = '$_SESSION[dept]'") or die(mysqli_error());
			$fetch = mysqli_fetch_array($query);
			?>
      <h4>Program Chair: 
        <label class="pull-right"><?php echo $fetch['ProgramChair']?></label>
      </h4>
      <?php $query = mysqli_query($conn, "SELECT * FROM `dean` WHERE `College` = '$_SESSION[college]'") or die(mysqli_error());
			$fetch = mysqli_fetch_array($query);
			?>
      <h4>Dean: 
        <label class="pull-right"><?php echo $fetch['Dean']?></label>
      </h4>
      <?php $query = mysqli_query($conn, "SELECT * FROM `management` WHERE `position` = 'Registrar'") or die(mysqli_error());
			$fetch = mysqli_fetch_array($query);
			?>
      <h4>University Registrar: 
        <label class="pull-right"><?php echo $fetch['name']?></label>
      </h4>
      <?php $query = mysqli_query($conn, "SELECT * FROM `management` WHERE `position` = 'HR head'") or die(mysqli_error());
			$fetch = mysqli_fetch_array($query);
			?>
      <h4>HR Head: 
        <label class="pull-right"><?php echo $fetch['name']?></label>
      </h4>
      <?php $query = mysqli_query($conn, "SELECT * FROM `management` WHERE `position` = 'VCAR'") or die(mysqli_error());
			$fetch = mysqli_fetch_array($query);
			?>
      <h4>VCAR: 
        <label class="pull-right"><?php echo $fetch['name']?></label>
      </h4>
      <?php $query = mysqli_query($conn, "SELECT * FROM `effectivitydate` WHERE effdate_id= '1'") or die(mysqli_error());
				$fetch = mysqli_fetch_array($query); ?>
      <h4>Schedule Effectivity Date: 
          <label class="pull-right"> <?php echo $fetch['effdate'] ?> </label>
    </h4> 
    <div>
  <?php include 'reminders.php'?>
  </div>
    </div>
  </div><div class="panel panel-default" style="margin-top:10px;" style="float: right; width: 70%"> 
  <div class="panel-body" style="float: right; width: 70%"> 
    <?php include 'profiletable.php'?>
  </div>
</div>

         

<div>
  <?php include 'timetable.php'?>
</div>

  <div>
  <?php include 'summary.php'?>
  </div>
  <?php $query = mysqli_query($conn, "SELECT * FROM `approval` WHERE `IDnum` = '$_SESSION[faculty]'") or die(mysqli_error());
			$fetch = mysqli_fetch_array($query);
			?>
  <?php 
  
	if($fetch['submitted'] == 'ok' || $fetch['progchair'] == 'ok')
	{
	echo '<button class="btn btn-success" disabled><span class="glyphicon glyphicon-save">Schedule Submitted</button>';
	}else
	{
	echo '<button class="btn btn-success" data-toggle="modal" data-target="#submit_approval"><span class="glyphicon glyphicon-plus">
		  </span>Submit to Program Chair</button>';
	}	
	?>	
	<a href="print_load.php?id='<?php echo $_SESSION['faculty']?>'" target="_blank" class="btn btn-success"><span class="glyphicon glyphicon-edit">
	Printable Plotting Form</a>
	
  </br> </br> </br> </br>   </div>
</div>

 <?php include 'addtime.php'?>
 
 <?php include 'progchair_load_updater_modal.php'?>
 
 <?php include 'submit_approval.php'?>
 
 <?php include 'delete.php'?>
 
 
	<div id = "footer">
		<label class = "footer-title">&copy; Copyright TED Teaching Load Tracking <?php echo date("Y", strtotime("+8 HOURS"))?></label>
	</div>
</div>
<?php include 'logoutmodal.php'?>		
<?php include 'script.php'?>
<script type="text/javascript">

	$('.btn-delete').on('click', function(){
		var user_id = $(this).attr('id');
		$("#modal_confirm").modal('show');
		$('#btn_yes').attr('name', user_id);
	});
	$('#btn_yes').on('click', function(){
		var id = $(this).attr('name');
		$.ajax({
			type: "POST",
			url: "delete_user.php",
			data:{
				user_id: id
			},
			success: function(){
				$("#modal_confirm").modal('hide');
				$(".del_user" + id).empty();
				$(".del_user" + id).html("<td colspan='6'><center class='text-danger'>Deleting...</center></td>");
				setTimeout(function(){
					$(".del_user" + id).fadeOut('slow');
				}, 1000);
			}
		});
	});
});
</script>	
</body>
</html>