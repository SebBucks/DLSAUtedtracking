<?php
	session_start();
	require_once 'admin/conn.php';
	$subjid = $_GET['id'];
	$first = rtrim($subjid,"'");
	$idtrim = ltrim($first, "'");
	mysqli_query($conn, "DELETE FROM `timetable` WHERE SubjectCode = '$idtrim'") or die(mysqli_error($conn));

	header("refresh:1; url=profile.php");

		
		
		
	
?>