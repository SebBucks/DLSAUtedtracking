<p align="left" style="margin-left:12.5%">Load Assignment: </p>
<table class="center" width="100%" style="border: 1px solid black; border-collapse: collapse;">
        <thead>
          <tr> 
		  	<th style="border: 1px solid black; border-collapse: collapse;">Load Type</th>
            <th style="border: 1px solid black; border-collapse: collapse;">SubjectCode</th>
            <th style="border: 1px solid black; border-collapse: collapse;">Subject Description</th>
			 <th style="border: 1px solid black; border-collapse: collapse;">Section</th>
            <th style="border: 1px solid black; border-collapse: collapse;">Time</th>
            <th style="border: 1px solid black; border-collapse: collapse;">Day</th>
            <th style="border: 1px solid black; border-collapse: collapse;">Room</th>
			<th style="border: 1px solid black; border-collapse: collapse;">Unit</th>
			<th style="border: 1px solid black; border-collapse: collapse;">Remarks</th>
          </tr>
        </thead>
        <tbody>
         <tr>
		  
		 
		 <?php
		 $total = 0;
		  $query = mysqli_query($conn, "SELECT * FROM `timetable` WHERE `Idnum` = '$idtrim' ") or die(mysqli_error());				
			while($fetch = mysqli_fetch_array($query)){
		 ?>
		 	<td style="border: 1px solid black; border-collapse: collapse;"><?php echo $fetch['ClassType']; ?></td>
		 	<td style="border: 1px solid black; border-collapse: collapse;"><?php echo $fetch['SubjectCode']; ?></td>
			<td style="border: 1px solid black; border-collapse: collapse;"><?php echo $fetch['Description']; ?></td>
			<td style="border: 1px solid black; border-collapse: collapse;"><?php echo $fetch['Section']; ?></td>
			<td style="border: 1px solid black; border-collapse: collapse;"><?php echo $fetch['StartTime']. " - " . $fetch['EndTime']; ?></td>
			<td style="border: 1px solid black; border-collapse: collapse;"><?php echo $fetch['Day']; ?></td>
			<td style="border: 1px solid black; border-collapse: collapse;"></td>
			<td style="border: 1px solid black; border-collapse: collapse;"><?php echo $fetch['Units']; ?></td>
			<?php
			$starttime= decimalHours($fetch['StartTime']);
	  		$endtime= decimalHours($fetch['EndTime']);
	  		$output = $endtime-$starttime;
	  		$output = $output * $fetch['daycount'];
	  		$total = $total + $output;	
			 ?>
			<td style="border: 1px solid black; border-collapse: collapse;"><?php echo round($output,2);?></td>
		 </tr>
		 <?php } ?>
        </tbody>
		<tfoot>
        <tr>
            <td class= "right"  colspan="8" style="border: 1px solid black; border-collapse: collapse;">Total:</td><td><?php echo $total;?></td>
        </tr>
    </tfoot>
  </table>
