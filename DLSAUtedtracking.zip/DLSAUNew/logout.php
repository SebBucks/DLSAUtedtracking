<?php
	session_start();
	unset($_SESSION['faculty']);
	header("location: index.php");
?>