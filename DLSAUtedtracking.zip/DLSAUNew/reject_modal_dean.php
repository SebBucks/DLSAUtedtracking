<div class="modal fade" id="reject_dean" aria-hidden="true">
	<div class="modal-dialog modal-dialog-centered">		
    	<div class="modal-content"> 
		 <div class="modal-header"> 
        <h3 class="modal-title">System</h3>
      <div class="modal-body"> 
        <center>
          <h4>Reject Schedule?</h4>
        </center>
      </div>
	  <form method="POST" action="reject_ok.php">
	  </br>
	  <label>Type of Problem</label>
	  <div class="form-group"> 
	     <input type="radio" id="regular" name="load" value="RL">
		� <label>Regular Load Problem</label></br>
		� <input type="radio" id="facultyload" name="load" value="COHOC">
		� <label>Consultation/Office/Off-Campus Load Problem</label></br>
		� <input type="radio" id="both" name="load" value="BOTH">
		� <label>Both</label>
		</div>
		<br>
		<label>Remarks:</label>
		<br>
	  	<textarea id="remarks" name="remarks" rows="4" cols="50"></textarea>
	  	<div class="modal-footer"> 
       	 <button name="reject" id="reject" class="btn btn-warning" ><span class="glyphicon glyphicon-trash"></span> 
          Reject</button>
		<button type="button" class="btn btn-danger" data-dismiss="modal"><span class="glyphicon glyphicon-remove"></span> 
          Cancel</button>
		</div>
		</form>
		
		</div>
	</div>
</div>
</div>