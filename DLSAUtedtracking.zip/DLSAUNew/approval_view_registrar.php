<?php
	session_start();
	require_once 'admin/conn.php';
	
	function decimalHours($time)
{
    $hms = explode(":", $time);
    return ($hms[0] + ($hms[1]/60) + ($hms[2]/3600));
}
?>
<html lang = "en">
	<head>
		<title>TED Teaching Load Tracking</title>
		<meta charset = "utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel = "stylesheet" type = "text/css" href = "admin/css/bootstrap.css" />
		<link rel = "stylesheet" type = "text/css" href = "admin/css/jquery.dataTables.css" />
		<link rel = "stylesheet" type = "text/css" href = "admin/css/style.css" />
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
		
	</head>
	
<body>
	<nav class="navbar navbar-default navbar-fixed-top" style="background-color:green;">
		<div class="container-fluid">
			<label class="navbar-brand" id="title">TED Teaching Load Tracking</label>
		</div>
	</nav>
	</br> </br> </br> </br>
<h2>REGISTRAR APPROVAL</h2>
<?php include 'approve_close_table_registrar.php'?>
	
<?php include 'approval_modal_registrar.php'?>

<?php include 'reject_modal_registrar.php'?>
	<div id = "footer">
		<label class = "footer-title">&copy; Copyright TED Teaching Load Tracking <?php echo date("Y", strtotime("+8 HOURS"))?></label>
	</div>
</div>
<?php include 'script.php'?>
<script type="text/javascript">
	$('.btn-delete').on('click', function(){
		var user_id = $(this).attr('id');
		$("#modal_confirm").modal('show');
		$('#btn_yes').attr('name', user_id);
	});
	$('#btn_yes').on('click', function(){
		var id = $(this).attr('name');
		$.ajax({
			type: "POST",
			url: "delete_user.php",
			data:{
				user_id: id
			},
			success: function(){
				$("#modal_confirm").modal('hide');
				$(".del_user" + id).empty();
				$(".del_user" + id).html("<td colspan='6'><center class='text-danger'>Deleting...</center></td>");
				setTimeout(function(){
					$(".del_user" + id).fadeOut('slow');
				}, 1000);
			}
		});
	});
});
</script>
</body>
</html>
	
