<table style="border: 1px solid black; border-collapse: collapse;">
<tr>
 		<td style="border: 1px solid black; border-collapse: collapse;" colspan="7" align="Center" > REMINDERS</td>
 		</td>
 		</tr>
 		<tr>
 		<td style="border: 1px solid black; border-collapse: collapse;" colspan="7" align="Left" > I.	Permanent and probationary full-time faculty must have 24 hours Regular Teaching Load for the 1st term, 20 hours Regular Teaching Load for the 2nd term and 20 hours Regular Teaching Load for the 3rd term.</td>
 		</td>
 		</tr>
 		<tr>
 		<td style="border: 1px solid black; border-collapse: collapse;" colspan="7" align="Left" >II.	Part-time faculty maximum per term Regular Teaching Load is 16 hours.</td>
 		</td>
 		</tr>
 		<tr>
 		<td style="border: 1px solid black; border-collapse: collapse;" colspan="7" align="Left" >III.	Exclusive to permanent and probationary full-time faculty only:
 		</br>
                          Non-Teaching Hours should be labeled as:
        </br>
1.	Off campus (5.5 hours per week)
</br>
2.	Consultation Hours (6 hours per week)
</br>
3.	Office Hours (7.5 hours per week)
</td>
 		</td>
 		</tr>
		
</table>