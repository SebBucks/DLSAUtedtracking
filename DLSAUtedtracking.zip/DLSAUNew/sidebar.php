<div id="sidebar">
	<ul id = "menu" class = "nav menu"> 
	<?php
			$query = mysqli_query($conn, "SELECT * FROM `faculty` WHERE `IDnum` = '$_SESSION[faculty]'") or die(mysqli_error());
			$fetch = mysqli_fetch_array($query);
			$management = $fetch['management'];
		?>
		<?php
		if($management == 'No')
		{
			echo '<li><a href = "profile.php"><i class = "glyphicon glyphicon-home"></i> Profile</a></li>';
		}
		?> 		
		<?php
		if($management == 'Yes')
		{
		$progchair="";
		$dean="";
		$registrar="";
		$hrhead="";
		$vcar="";
			$query = mysqli_query($conn, "SELECT * FROM `management` WHERE `IDnum` = '$_SESSION[faculty]'") or die(mysqli_error());
			while($fetch = mysqli_fetch_array($query)){
			$position = trim($fetch['position']);
				if($position == trim("ProgramChair")){
					$progchair = $position;
				}
				if($position == trim("Dean")){			
					$dean = $position;	
				}				
				if($position == trim("Registrar")){
					$registrar = $position;
				}
				if($position == trim("HR head")){
					$hrhead = $position;
				}
				if($position == trim("VCAR")){
					$vcar = $position;
				}
			}
			
			if ($progchair == "ProgramChair")
			{
			echo '<li><a href = "progchair_profile.php"><i class = "glyphicon glyphicon-user"></i> Program Chair</a></li>';
			}
			if ($dean == "Dean")
			{
			echo '<li><a href = "dean_profile.php"><i class = "glyphicon glyphicon-user"></i> Dean</a></li>';
			}
			
			if ($registrar == "Registrar")
			{
			echo '<li><a href = "registrar_profile.php"><i class = "glyphicon glyphicon-user"></i> Registrar</a></li>';
			}
			if ($hrhead== "HR head")
			{
			echo '<li><a href = "hrhead_profile.php"><i class = "glyphicon glyphicon-user"></i> HR Head</a></li>';
			}
			if ($vcar == "VCAR")
			{
			echo '<li><a href = "vcar_profile.php"><i class = "glyphicon glyphicon-user"></i> VCAR</a></li>';
			}
			//echo '<li><a href = "management.php"><i class = "glyphicon glyphicon-user"></i> Management</a></li>';
	}
		?> 
	
	</ul>
</div>