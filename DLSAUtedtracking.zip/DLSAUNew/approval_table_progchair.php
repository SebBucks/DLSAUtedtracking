<h3>Program Chair Approval</h3>
<table id= "table3"  tableclass="table table-bordered">
<?php 
$idcheck = '';
$department = ''; 
$facdept = '';
$approvalcheck = '';
?>
<?php
	$idnum = $_SESSION['faculty'];
			$query = mysqli_query($conn, "SELECT * FROM programchair WHERE IDnum = '$idnum' ") or die(mysqli_error());				
			while($fetch = mysqli_fetch_array($query)){
				$department = trim($fetch['Department']);
				}
						?>
        <thead>
          <tr> 
            <th>ID number</th>
			<th>Name</th>
			<th>Check Schedule</th>
			</tr>			
        </thead>
        <tbody id = "tablebody" >
		<?php
			$query = mysqli_query($conn, "SELECT * FROM approval WHERE submitted = 'ok' ") or die(mysqli_error());				
			while($fetch = mysqli_fetch_array($query)){
				$idcheck = $fetch['IDnum'];
				$approvalcheck = $fetch['progsub'];					
						?>
		
		<?php 
		 if($approvalcheck <> 'ok'){
				//echo '<td></td><td></td><td></td>';
		//}else{
				?>
		 <?php
			$query1 = mysqli_query($conn, "SELECT * FROM faculty WHERE Idnum = '$idcheck' ") or die(mysqli_error());				
			while($fetch1 = mysqli_fetch_array($query1)){
				$facdept = trim($fetch1['Department']);
				// echo $department;
	  			// echo $facdept;
					if ($department == $facdept){
						?>
		<tr class="del_user<?php echo $idcheck?>">
         <td><?php echo $idcheck?></td>
		 <td><?php echo $fetch1['firstname']?> <?php echo " " ?><?php echo $fetch1['lastname']?></td>   
		
	 <td><a href="approval_view_progchair.php?id='<?php echo $fetch1['Idnum']?>'" target="_blank" class="btn btn-warning"><span class="glyphicon glyphicon-edit">Check</a></td> 
		</tr>
		<?php 
			}
		}
    }	
}	
		?>
	
	    </tbody>
      </table>